import type { ArchConfig, MotorcycleProfile } from '../types/ecu';

export const ARCH_CONFIGS: Record<string, ArchConfig> = {
  SHIN_V850_G2: {
    size: '128KB',
    vendor: 'Shindengen V850',
    fuelOffset: '0x5100',
    ignOffset: '0x5400',
    limiterOffset: '0x0820',
    rows: 16,
    cols: 16,
    o2Offset: '0x03C1',
    sideOffset: '0x03C0',
    checksumType: 'Shindengen V850 Inverted Sum16',
    icon: '🛵',
  },
  SHIN_V850_G3: {
    size: '128KB',
    vendor: 'Shindengen V850',
    fuelOffset: '0x6200',
    ignOffset: '0x6600',
    limiterOffset: '0x09F0',
    rows: 20,
    cols: 16,
    o2Offset: '0x0480',
    sideOffset: '0x0481',
    checksumType: 'Shindengen eSP+ Sum16 Block',
    icon: '🛵',
  },
  SHIN_V850_G1: {
    size: '128KB',
    vendor: 'Shindengen V850',
    fuelOffset: '0x4200',
    ignOffset: '0x4500',
    limiterOffset: '0x0710',
    rows: 18,
    cols: 16,
    o2Offset: '0x02B0',
    sideOffset: '0x02B1',
    checksumType: 'Shindengen Keyless Sum16',
    icon: '🛵',
  },
  KEIHIN_64K_G2: {
    size: '64KB',
    vendor: 'Keihin',
    fuelOffset: '0x2800',
    ignOffset: '0x2A50',
    limiterOffset: '0x0520',
    rows: 16,
    cols: 16,
    o2Offset: '0x02A2',
    sideOffset: '0x02A1',
    checksumType: 'Keihin Inverted Sum16 Complement',
    icon: '🏍️',
  },
  KEIHIN_64K_G1: {
    size: '64KB',
    vendor: 'Keihin',
    fuelOffset: '0x1400',
    ignOffset: '0x1600',
    limiterOffset: '0x0380',
    rows: 14,
    cols: 14,
    o2Offset: '0x011A',
    sideOffset: '0x011B',
    checksumType: 'Keihin Sum16 Standard',
    icon: '🛵',
  },
  KEIHIN_32K_OLD: {
    size: '32KB',
    vendor: 'Keihin',
    fuelOffset: '0x0A20',
    ignOffset: '0x0B40',
    limiterOffset: '0x0182',
    rows: 10,
    cols: 10,
    o2Offset: '0x00FF',
    sideOffset: '0x00FE',
    checksumType: 'Keihin 32KB Bebek Checksum',
    icon: '🏍️',
  },
  KEIHIN_256K_TBW: {
    size: '256KB',
    vendor: 'Keihin TBW',
    fuelOffset: '0x8200',
    ignOffset: '0x8600',
    limiterOffset: '0x1200',
    rows: 24,
    cols: 20,
    o2Offset: '0x0520',
    sideOffset: '0x0521',
    checksumType: 'Keihin 256KB Twin CRC Checksum',
    icon: '🏎️',
  },
};

export const ARCH_LABELS: Record<string, string> = {
  SHIN_V850_G2: 'Shindengen V850 Gen 2 (Vario 125 K2V/K2VG, BeAT eSAF K1A, Genio K0J, Scoopy K2F)',
  SHIN_V850_G3: 'Shindengen V850 Gen 3 (Stylo 160 K3V, PCX 160 K1Z, Vario 160 K2S, ADV 160)',
  SHIN_V850_G1: 'Shindengen V850 Gen 1 (Vario 150 Keyless K59J, PCX 150 K97, ADV 150 K0W)',
  KEIHIN_64K_G2: 'Keihin 64KB Gen 2 ACG / LED (BeAT K44, Vario 150 K59 Old, Vario 125 K60, CRF K84, CB150R, Sonic K56)',
  KEIHIN_64K_G1: 'Keihin 64KB Gen 1 Starter Kasar (BeAT FI K25, Scoopy K16, Vario 125 KZR Bohlam Old)',
  KEIHIN_32K_OLD: 'Keihin 32KB Bebek Injeksi Awal (Supra X 125 KPH, Helm-In KYZ)',
  KEIHIN_256K_TBW: 'Keihin 256KB Twin Cylinder Throttle-by-Wire (CBR250RR K64)',
};

export const DEFAULT_HONDA_DATABASE: MotorcycleProfile[] = [
  { id: '30400-K2VG-N42', calId: '0104D80F01', name: 'Vario 125 New eSP CBS ISS Keyless (2022-2024)', issType: 'ISS Smartkey', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x5100', ignOffset: '0x5400', limiterOffset: '0x0820', rows: 16, cols: 16, icon: '🛵' },
  { id: '30400-K2VG-N32', calId: '01046B0F01', name: 'Vario 125 New eSP CBS Non-ISS (2022-2024)', issType: 'Non-ISS (CBS)', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x5100', ignOffset: '0x5400', limiterOffset: '0x0820', rows: 16, cols: 16, icon: '🛵' },
  { id: '30400-K2V-NA1', calId: '0105B80F01', name: 'New Vario 125 Facelift Smartkey (2024-2026+)', issType: 'ISS Smartkey', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x5100', ignOffset: '0x5400', limiterOffset: '0x0820', rows: 16, cols: 16, icon: '🛵' },
  { id: '30400-K59J-A71', calId: '01037B0F01', name: 'Vario 150 All New Smartkey K59J (2018-2020)', issType: 'ISS Smartkey', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x4200', ignOffset: '0x4500', limiterOffset: '0x0710', rows: 18, cols: 16, icon: '🛵' },
  { id: '38770-K59-A11', calId: '0102170A01', name: 'Vario 150 eSP LED Old K59 (2015-2017)', issType: 'ISS Exclusive', size: '64KB', vendor: 'Keihin', fuelOffset: '0x2800', ignOffset: '0x2A50', limiterOffset: '0x0520', rows: 16, cols: 16, icon: '🛵' },
  { id: '30400-K60-B11', calId: '0101411102', name: 'Vario 125 LED Old ISS K60 (2015-2017)', issType: 'ISS (CBS ISS)', size: '64KB', vendor: 'Keihin', fuelOffset: '0x2800', ignOffset: '0x2A50', limiterOffset: '0x0520', rows: 16, cols: 16, icon: '🛵' },
  { id: '30400-KZRA-601', calId: 'KZR601', name: 'Vario 125 Old Bohlam Non-ISS KZR (2012-2014)', issType: 'Non-ISS (Standar)', size: '64KB', vendor: 'Keihin', fuelOffset: '0x1400', ignOffset: '0x1600', limiterOffset: '0x0380', rows: 14, cols: 14, icon: '🛵' },
  { id: '30400-K2SA-N02', calId: '01046B0F01', name: 'Vario 160 eSP+ CBS K2SA (2022-2024)', issType: 'ISS (CBS Smartkey)', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x6200', ignOffset: '0x6600', limiterOffset: '0x09F0', rows: 20, cols: 16, icon: '🛵' },
  { id: '38770-K3V-N01', calId: '0105B10F01', name: 'Stylo 160 eSP+ 4V K3V CBS (2024-2026+)', issType: 'ISS (CBS Smartkey)', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x6200', ignOffset: '0x6600', limiterOffset: '0x09F0', rows: 20, cols: 16, icon: '🛵' },
  { id: '38770-K25-901', calId: 'K25901', name: 'BeAT FI Starter Kasar Non-ESP (2012-2014)', issType: 'Non-ISS (Standar)', size: '64KB', vendor: 'Keihin', fuelOffset: '0x1200', ignOffset: '0x1400', limiterOffset: '0x0342', rows: 12, cols: 12, icon: '🛵' },
  { id: '30400-K1A-N01', calId: '0101D40F01', name: 'BeAT LED eSAF (2020-2024) Non-ISS', issType: 'Non-ISS (CBS)', size: '128KB', vendor: 'Shindengen V850', fuelOffset: '0x5100', ignOffset: '0x5400', limiterOffset: '0x0820', rows: 16, cols: 16, icon: '🛵' },
  { id: '38770-K84-901', calId: 'K84901', name: 'CRF 150L Trail Injeksi K84 (2017-2021)', issType: 'Manual Sport', size: '64KB', vendor: 'Keihin', fuelOffset: '0x2800', ignOffset: '0x2A50', limiterOffset: '0x0520', rows: 16, cols: 16, icon: '🚵' },
  { id: '38770-K45-N01', calId: 'K45N01', name: 'All New CBR 150R LED K45G (2016-2018)', issType: 'Manual Sport', size: '64KB', vendor: 'Keihin', fuelOffset: '0x2800', ignOffset: '0x2A50', limiterOffset: '0x0520', rows: 18, cols: 16, icon: '🏍️' },
  { id: '38770-K56-N01', calId: 'K56N01', name: 'Sonic 150R DOHC 6-Speed K56 (2015-2024+)', issType: 'Manual Sport', size: '64KB', vendor: 'Keihin', fuelOffset: '0x2800', ignOffset: '0x2A50', limiterOffset: '0x0520', rows: 18, cols: 16, icon: '🏍️' },
  { id: '38770-KPH-881', calId: 'KPH881', name: 'Supra X 125 PGM-FI Perdana (2005-2009)', issType: 'Non-ISS (Bebek)', size: '32KB', vendor: 'Keihin', fuelOffset: '0x0A20', ignOffset: '0x0B40', limiterOffset: '0x0182', rows: 10, cols: 10, icon: '🏍️' },
];

const CUSTOM_DB_STORAGE_KEY = 'younk_custom_db';

export function getCustomMotorcycles(): MotorcycleProfile[] {
  try {
    const raw = localStorage.getItem(CUSTOM_DB_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function getMergedMotorcycleDatabase(): MotorcycleProfile[] {
  return [...getCustomMotorcycles(), ...DEFAULT_HONDA_DATABASE];
}

export function saveCustomMotorcycleToStorage(bike: MotorcycleProfile): MotorcycleProfile[] {
  const existing = getCustomMotorcycles();
  const next = [{ ...bike, isCustom: true }, ...existing];
  localStorage.setItem(CUSTOM_DB_STORAGE_KEY, JSON.stringify(next));
  return [...next, ...DEFAULT_HONDA_DATABASE];
}

export const ANDROID_MANIFEST_XML_SNIPPET = `<!-- 1. Tambahkan di AndroidManifest.xml -->
<uses-feature android:name="android.hardware.usb.host" android:required="true" />
<uses-permission android:name="android.permission.USB_PERMISSION" />
<uses-permission android:name="android.permission.INTERNET" />

<!-- Di dalam <activity> utama tambahkan intent-filter USB OTG: -->
<intent-filter>
    <action android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED" />
</intent-filter>
<meta-data
    android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED"
    android:resource="@xml/device_filter" />

<!-- 2. Buat file res/xml/device_filter.xml -->
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- FTDI FT232R / FT232H / FT2232 -->
    <usb-device vendor-id="1027" />
    <!-- WCH CH340 / CH341 -->
    <usb-device vendor-id="6790" />
    <!-- Silicon Labs CP210x -->
    <usb-device vendor-id="4292" />
    <!-- Prolific PL2303 -->
    <usb-device vendor-id="1659" />
</resources>`;
