import type { OtgDeviceInfo, OtgDiagnostics } from '../types/ecu';

export const USB_OTG_FILTERS: USBDeviceFilter[] = [
  { vendorId: 0x0403 }, // FTDI (FT232R, FT232H, FT2232)
  { vendorId: 0x1A86 }, // WCH CH340 / CH341 / CH9102
  { vendorId: 0x10C4 }, // Silicon Labs CP2102 / CP2104
  { vendorId: 0x067B }, // Prolific PL2303
  { vendorId: 0x2341 }, // Arduino / CDC
  { classCode: 0x02 },  // USB CDC-ACM
];

export function getUsbChipName(vid: number): string {
  switch (vid) {
    case 0x0403:
      return 'FTDI (FT232R/FT2232)';
    case 0x1A86:
      return 'WCH CH340/CH341';
    case 0x10C4:
      return 'Silicon Labs CP210x';
    case 0x067B:
      return 'Prolific PL2303';
    case 0x2341:
      return 'Arduino / CDC';
    default:
      return 'USB Serial / CDC-ACM';
  }
}

export function isAndroidDevice(): boolean {
  return typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
}

export function formatUsbDeviceInfo(device: USBDevice): OtgDeviceInfo {
  const vid = device.vendorId.toString(16).toUpperCase().padStart(4, '0');
  const pid = device.productId.toString(16).toUpperCase().padStart(4, '0');
  const chipset = getUsbChipName(device.vendorId);
  return {
    name: device.productName || chipset,
    chipset,
    vendorIdHex: vid,
    productIdHex: pid,
    rawDevice: device,
  };
}

export interface TransportBridge {
  mode: 'WEBUSB' | 'WEBSERIAL';
  label: string;
  write: (data: Uint8Array) => Promise<void>;
  readWithTimeout: (ms?: number) => Promise<Uint8Array>;
  close: () => Promise<void>;
}

export class WebUSBSerialDriver {
  private device: USBDevice;
  private vid: number;
  private dataIface = 0;
  private ctrlIface = 0;
  private epIn = 1;
  private epOut = 2;
  private isCdc = false;
  public isOpen = false;

  constructor(device: USBDevice) {
    this.device = device;
    this.vid = device.vendorId;
  }

  async open(baudRate = 10400): Promise<void> {
    await this.device.open();
    if (this.device.configuration === null) {
      await this.device.selectConfiguration(1);
    }

    const interfaces = this.device.configuration?.interfaces ?? [];
    let foundData = false;
    for (const iface of interfaces) {
      const alt = iface.alternates[0];
      if (!alt) continue;
      if (alt.interfaceClass === 0x02) {
        this.ctrlIface = iface.interfaceNumber;
        this.isCdc = true;
      }
      let inEp: number | null = null;
      let outEp: number | null = null;
      for (const ep of alt.endpoints) {
        if (ep.type === 'bulk' && ep.direction === 'in') inEp = ep.endpointNumber;
        if (ep.type === 'bulk' && ep.direction === 'out') outEp = ep.endpointNumber;
      }
      if (inEp !== null && outEp !== null && !foundData) {
        this.dataIface = iface.interfaceNumber;
        this.epIn = inEp;
        this.epOut = outEp;
        foundData = true;
      }
    }

    if (this.isCdc && this.ctrlIface !== this.dataIface) {
      try {
        await this.device.claimInterface(this.ctrlIface);
      } catch {
        // Control interface might already be managed by composite driver
      }
    }
    await this.device.claimInterface(this.dataIface);
    await this.initChipset(baudRate);
    this.isOpen = true;
  }

  private async initChipset(baudRate: number): Promise<void> {
    if (this.vid === 0x0403) {
      // FTDI FT232R / FT2232
      const portIdx = this.dataIface + 1;
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x00, value: 0x0000, index: portIdx });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x00, value: 0x0001, index: portIdx });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x00, value: 0x0002, index: portIdx });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x09, value: 0x0001, index: portIdx });

      const divisor = Math.round((3000000 * 8) / baudRate);
      const divFrac = [0, 3, 2, 4, 1, 5, 6, 7];
      const encoded = (divisor >> 3) | (divFrac[divisor & 0x7] << 14);
      const val = encoded & 0xffff;
      const idx = ((encoded >> 16) & 0xffff) | (this.dataIface > 0 ? portIdx << 8 : 0);
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x03, value: val, index: idx });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x04, value: 0x0008, index: portIdx });
    } else if (this.vid === 0x10C4) {
      // Silicon Labs CP210x
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'interface', request: 0x00, value: 0x0001, index: this.dataIface });
      const baudBuf = new ArrayBuffer(4);
      new DataView(baudBuf).setUint32(0, baudRate, true);
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'interface', request: 0x1e, value: 0x0000, index: this.dataIface }, baudBuf);
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'interface', request: 0x03, value: 0x0800, index: this.dataIface });
    } else if (this.vid === 0x1A86) {
      // WCH CH340 / CH341 (10400 bps)
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0xa1, value: 0x0000, index: 0x0000 });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x9a, value: 0x1312, index: 0x7082 });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0x9a, value: 0x0f2c, index: 0x0008 });
      await this.device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request: 0xa4, value: 0x00ff, index: 0x0000 });
    } else {
      // USB CDC-ACM (Generic)
      const lineCoding = new ArrayBuffer(7);
      const dv = new DataView(lineCoding);
      dv.setUint32(0, baudRate, true);
      dv.setUint8(4, 0);
      dv.setUint8(5, 0);
      dv.setUint8(6, 8);
      await this.device.controlTransferOut({ requestType: 'class', recipient: 'interface', request: 0x20, value: 0, index: this.ctrlIface }, lineCoding);
      await this.device.controlTransferOut({ requestType: 'class', recipient: 'interface', request: 0x22, value: 0x03, index: this.ctrlIface });
    }
  }

  async setBreak(on: boolean): Promise<void> {
    if (this.vid === 0x0403) {
      const portIdx = this.dataIface + 1;
      await this.device.controlTransferOut({
        requestType: 'vendor',
        recipient: 'device',
        request: 0x04,
        value: on ? 0x4008 : 0x0008,
        index: portIdx,
      });
    } else if (this.vid === 0x10C4) {
      await this.device.controlTransferOut({
        requestType: 'vendor',
        recipient: 'interface',
        request: 0x05,
        value: on ? 0x0001 : 0x0000,
        index: this.dataIface,
      });
    } else if (this.vid === 0x1A86) {
      await this.device.controlTransferOut({
        requestType: 'vendor',
        recipient: 'device',
        request: 0x9a,
        value: 0x0005,
        index: on ? 0x0000 : 0x00ff,
      });
    } else {
      await this.device.controlTransferOut({
        requestType: 'class',
        recipient: 'interface',
        request: 0x23,
        value: on ? 0xffff : 0x0000,
        index: this.ctrlIface,
      });
    }
  }

  async write(uint8Data: Uint8Array): Promise<void> {
    await this.device.transferOut(this.epOut, uint8Data as BufferSource);
  }

  async readWithTimeout(ms = 2500): Promise<Uint8Array> {
    const deadline = Date.now() + ms;
    while (Date.now() < deadline) {
      const remain = Math.max(50, deadline - Date.now());
      const res = await Promise.race([
        this.device.transferIn(this.epIn, 64),
        new Promise<never>((_, rej) => setTimeout(() => rej(new Error('TIMEOUT')), remain)),
      ]);
      if (res && res.data && res.data.byteLength > 0) {
        const raw = new Uint8Array(res.data.buffer);
        const payload = this.vid === 0x0403 ? raw.slice(2) : raw;
        if (payload.length > 0) return payload;
      }
      await new Promise((r) => setTimeout(r, 15));
    }
    throw new Error('TIMEOUT');
  }

  async close(): Promise<void> {
    this.isOpen = false;
    try {
      await this.device.releaseInterface(this.dataIface);
    } catch {
      // Ignore release errors on detached cable
    }
    try {
      await this.device.close();
    } catch {
      // Ignore close errors
    }
  }
}

export async function inspectOtgDiagnostics(): Promise<OtgDiagnostics> {
  const hasWebUsb = typeof navigator !== 'undefined' && 'usb' in navigator;
  const hasWebSerial = typeof navigator !== 'undefined' && 'serial' in navigator;
  let authorizedDevice: OtgDeviceInfo | null = null;

  if (hasWebUsb && navigator.usb) {
    try {
      const devices = await navigator.usb.getDevices();
      if (devices.length > 0) {
        authorizedDevice = formatUsbDeviceInfo(devices[0]);
      }
    } catch {
      authorizedDevice = null;
    }
  }

  return {
    isAndroid: isAndroidDevice(),
    isSecureContext: typeof window !== 'undefined' ? window.isSecureContext : false,
    protocol: typeof location !== 'undefined' ? location.protocol : 'unknown:',
    hasWebUsb,
    hasWebSerial,
    authorizedDevice,
  };
}

export function bytesToHex(data: Uint8Array): string {
  return Array.from(data)
    .map((b) => b.toString(16).padStart(2, '0').toUpperCase())
    .join(' ');
}

export const KLINE_PACKETS = {
  WAKEUP: new Uint8Array([0x72, 0x05, 0x00, 0xf0, 0x99]),
  ECU_ID_REQ: new Uint8Array([0x72, 0x05, 0x71, 0x00, 0x18]),
  RELAY_FUEL_PUMP: new Uint8Array([0x72, 0x06, 0x30, 0x01, 0x01, 0x56]),
  RELAY_STARTER: new Uint8Array([0x72, 0x06, 0x30, 0x02, 0x01, 0x55]),
  SMARTKEY_PIN_REQ: new Uint8Array([0x72, 0x05, 0x72, 0x10, 0x07]),
};
