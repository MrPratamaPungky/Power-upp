import React, { useEffect, useRef, useState } from 'react';
import { Lock, FolderOpen, RotateCcw, Sliders, Activity } from 'lucide-react';
import type {
  MapParameter,
  MapSubView,
  MotorcycleProfile,
  PresetKey,
} from '../types/ecu';

interface TunerDeckLayerProps {
  database: MotorcycleProfile[];
  selectedBikeIndex: string;
  activeBikeBanner: {
    name: string;
    details: string;
    icon: string;
  } | null;
  isTableLoaded: boolean;
  rows: number;
  cols: number;
  rpmBins: number[];
  tpsBins: number[];
  fuelMap: number[][];
  ignMap: number[][];
  activeParam: MapParameter;
  subView: MapSubView;
  activePreset: PresetKey;
  selectedCell: { r: number; c: number };
  onSelectBike: (indexStr: string) => void;
  onImportMapFile: (file: File) => void;
  onResetStandby: () => void;
  onChangeParam: (param: MapParameter) => void;
  onChangeSubView: (view: MapSubView) => void;
  onSelectCell: (r: number, c: number) => void;
  onUpdateCell: (r: number, c: number, val: number) => void;
  onAdjustSelectedCell: (delta: number) => void;
  onApplyPreset: (preset: PresetKey) => void;
  onSmoothInterpolate: () => void;
}

const PRESET_LIST: Array<{ key: PresetKey; label: string }> = [
  { key: 'STD', label: 'STD' },
  { key: 'TOURING', label: 'TOURING' },
  { key: 'STOP_N_GO', label: 'STOP N GO' },
  { key: 'RACE', label: 'RACE' },
  { key: 'DRAG', label: 'DRAG' },
  { key: 'TIMING_KUDA', label: 'TIMING KUDA' },
  { key: 'IDLE_ROTARY', label: 'ROTARY' },
  { key: 'BLACK_FAIR', label: 'BLACK FAIR' },
];

export const TunerDeckLayer: React.FC<TunerDeckLayerProps> = ({
  database,
  selectedBikeIndex,
  activeBikeBanner,
  isTableLoaded,
  rows,
  cols,
  rpmBins,
  tpsBins,
  fuelMap,
  ignMap,
  activeParam,
  subView,
  activePreset,
  selectedCell,
  onSelectBike,
  onImportMapFile,
  onResetStandby,
  onChangeParam,
  onChangeSubView,
  onSelectCell,
  onUpdateCell,
  onAdjustSelectedCell,
  onApplyPreset,
  onSmoothInterpolate,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const canvas2DRef = useRef<HTMLCanvasElement | null>(null);
  const canvas3DRef = useRef<HTMLCanvasElement | null>(null);

  const [editingCell, setEditingCell] = useState<{ r: number; c: number; draft: string } | null>(null);
  const drag2DColRef = useRef<number>(-1);
  const rotRef = useRef<{ x: number; z: number; dragging: boolean; lastX: number; lastY: number }>({
    x: (55 * Math.PI) / 180,
    z: (45 * Math.PI) / 180,
    dragging: false,
    lastX: 0,
    lastY: 0,
  });

  const currentMatrix = activeParam === 'IGN' ? ignMap : fuelMap;

  // Render 2D Curve Canvas
  useEffect(() => {
    if (!isTableLoaded || subView !== 'CURVE2D') return;
    const canvas = canvas2DRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const parentWidth = canvas.parentElement?.clientWidth || 640;
    canvas.width = parentWidth;
    canvas.height = 220;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, w, h);

    // Subtle grid
    ctx.strokeStyle = '#161B26';
    ctx.lineWidth = 1;
    for (let i = 1; i < 6; i++) {
      const y = (h / 6) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const rowValues = currentMatrix[selectedCell.r] || [];
    if (rowValues.length === 0) return;

    const minVal = activeParam === 'IGN' ? 5 : 8;
    const span = activeParam === 'IGN' ? 35 : 16;

    ctx.strokeStyle = '#06B6D4';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    rowValues.forEach((val, c) => {
      const x = (c / Math.max(1, cols - 1)) * (w - 32) + 16;
      const y = h - 18 - ((val - minVal) / span) * (h - 36);
      if (c === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    rowValues.forEach((val, c) => {
      const x = (c / Math.max(1, cols - 1)) * (w - 32) + 16;
      const y = h - 18 - ((val - minVal) / span) * (h - 36);
      const isSel = c === selectedCell.c;
      ctx.fillStyle = isSel ? '#FF1E42' : '#10B981';
      ctx.beginPath();
      ctx.arc(x, y, isSel ? 7 : 4.5, 0, Math.PI * 2);
      ctx.fill();
    });
  }, [isTableLoaded, subView, currentMatrix, selectedCell, cols, activeParam]);

  // Render 3D Surface Canvas
  const draw3D = () => {
    const canvas = canvas3DRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const parentWidth = canvas.parentElement?.clientWidth || 640;
    canvas.width = parentWidth;
    canvas.height = 290;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, w, h);

    const cx = w / 2;
    const cy = h / 2 + 18;
    const scale = Math.min(w, 680) / 26;
    const cz = Math.cos(rotRef.current.z);
    const sz = Math.sin(rotRef.current.z);
    const cxRot = Math.cos(rotRef.current.x);
    const sxRot = Math.sin(rotRef.current.x);

    const proj = (x: number, y: number, z: number) => {
      const x1 = x * cz - y * sz;
      const y1 = x * sz + y * cz;
      const y2 = y1 * cxRot - z * sxRot;
      return { u: cx + x1 * scale, v: cy + y2 * scale };
    };

    const baseOffset = activeParam === 'IGN' ? 14 : 11;
    const normSpan = activeParam === 'IGN' ? 24 : 12;

    for (let r = 0; r < rows - 1; r++) {
      for (let c = 0; c < cols - 1; c++) {
        const v00 = currentMatrix[r]?.[c] ?? 12;
        const v01 = currentMatrix[r]?.[c + 1] ?? 12;
        const v11 = currentMatrix[r + 1]?.[c + 1] ?? 12;
        const v10 = currentMatrix[r + 1]?.[c] ?? 12;

        const p0 = proj(c - cols / 2, r - rows / 2, (v00 - baseOffset) * 0.65);
        const p1 = proj(c + 1 - cols / 2, r - rows / 2, (v01 - baseOffset) * 0.65);
        const p2 = proj(c + 1 - cols / 2, r + 1 - rows / 2, (v11 - baseOffset) * 0.65);
        const p3 = proj(c - cols / 2, r + 1 - rows / 2, (v10 - baseOffset) * 0.65);

        const avg = (v00 + v11) / 2;
        const norm = Math.max(0, Math.min(1, (avg - (baseOffset - 2)) / normSpan));
        ctx.fillStyle = `hsl(${(1 - norm) * 230}, 85%, 38%)`;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(p0.u, p0.v);
        ctx.lineTo(p1.u, p1.v);
        ctx.lineTo(p2.u, p2.v);
        ctx.lineTo(p3.u, p3.v);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
    }
  };

  useEffect(() => {
    if (!isTableLoaded || subView !== 'SURFACE3D') return;
    draw3D();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isTableLoaded, subView, currentMatrix, rows, cols, activeParam]);

  const handle2DPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvas2DRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const w = canvas.width;
    const h = canvas.height;
    const rowValues = currentMatrix[selectedCell.r] || [];
    const minVal = activeParam === 'IGN' ? 5 : 8;
    const span = activeParam === 'IGN' ? 35 : 16;

    let closestCol = -1;
    let minDist = 36;
    for (let c = 0; c < cols; c++) {
      const px = (c / Math.max(1, cols - 1)) * (w - 32) + 16;
      const py = h - 18 - (((rowValues[c] ?? minVal) - minVal) / span) * (h - 36);
      const dist = Math.hypot(px - x, py - y);
      if (dist < minDist) {
        minDist = dist;
        closestCol = c;
      }
    }

    if (closestCol !== -1) {
      drag2DColRef.current = closestCol;
      canvas.setPointerCapture(e.pointerId);
      onSelectCell(selectedCell.r, closestCol);
      const norm = Math.max(0, Math.min(1, 1 - (y - 18) / (h - 36)));
      onUpdateCell(selectedCell.r, closestCol, minVal + norm * span);
    }
  };

  const handle2DPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (drag2DColRef.current === -1) return;
    const canvas = canvas2DRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const y = e.clientY - rect.top;
    const h = canvas.height;
    const minVal = activeParam === 'IGN' ? 5 : 8;
    const span = activeParam === 'IGN' ? 35 : 16;
    const norm = Math.max(0, Math.min(1, 1 - (y - 18) / (h - 36)));
    onUpdateCell(selectedCell.r, drag2DColRef.current, minVal + norm * span);
  };

  const handle2DPointerUp = () => {
    drag2DColRef.current = -1;
  };

  const commitInlineEdit = () => {
    if (!editingCell) return;
    const parsed = parseFloat(editingCell.draft);
    if (!Number.isNaN(parsed)) {
      onUpdateCell(editingCell.r, editingCell.c, parsed);
    }
    setEditingCell(null);
  };

  return (
    <div className="space-y-4">
      {/* Source Selection Panel */}
      <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              Sumber Pemetaan &amp; Pilih Motor
            </h2>
            <p className="text-xs text-slate-400">
              Pilih katalog ECU motor secara manual atau muat file peta (.BIN / .JSON / .XDF).
            </p>
          </div>
          <button
            type="button"
            onClick={onResetStandby}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-md border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Tutup Tabel (Reset)
          </button>
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div>
            <label htmlFor="map-ecu-selector" className="mb-1.5 block text-xs font-medium text-slate-300">
              1. Pilih Tipe Motor Manual
            </label>
            <select
              id="map-ecu-selector"
              value={selectedBikeIndex}
              onChange={(e) => onSelectBike(e.target.value)}
              className="min-h-[44px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
            >
              <option value="">-- Silakan Pilih Tipe Motor Manual --</option>
              {database.map((m, idx) => (
                <option key={`${m.id}-${idx}`} value={String(idx)}>
                  {m.icon} {m.id} | {m.name} [{m.issType}]
                </option>
              ))}
            </select>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-300">
              2. Atau Buka File Map (.BIN / .JSON / .XDF)
            </span>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-md bg-cyan-500 px-4 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-cyan-400 whitespace-nowrap"
            >
              <FolderOpen className="h-4 w-4" />
              Buka File Dari Memori
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".bin,.json,.xdf"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) onImportMapFile(file);
                e.target.value = '';
              }}
            />
          </div>
        </div>
      </section>

      {/* Active Bike Banner */}
      {isTableLoaded && activeBikeBanner && (
        <section className="flex items-center gap-3.5 rounded-lg border border-rose-500/40 bg-[#150C12] px-4 py-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md border border-cyan-500/40 bg-[#090B10] text-2xl">
            {activeBikeBanner.icon}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate font-[var(--font-display)] text-base font-bold text-white">
              {activeBikeBanner.name}
            </div>
            <div className="truncate font-mono text-xs text-slate-300 tabular-nums">
              {activeBikeBanner.details}
            </div>
          </div>
        </section>
      )}

      {/* Matrix Workspace */}
      <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-[#FF1E42]" />
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              {isTableLoaded ? `Peta Matriks Aktif (${rows}×${cols})` : 'Peta Matriks Tuning'}
            </h2>
          </div>
          <span
            className={`font-mono text-xs font-semibold ${
              isTableLoaded ? 'text-emerald-400' : 'text-amber-400'
            }`}
          >
            {isTableLoaded ? '● Peta Aktif' : '■ Standby (Terkunci)'}
          </span>
        </div>

        {!isTableLoaded ? (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-slate-700 bg-[#090B10] px-6 py-12 text-center">
            <Lock className="mb-3 h-8 w-8 text-slate-400" />
            <h3 className="text-base font-semibold text-slate-100">
              Tabel Pemetaan Belum Diaktifkan
            </h3>
            <p className="mt-1.5 max-w-lg text-sm leading-relaxed text-slate-400">
              Tabel matriks 2D dan grafik dikunci saat awal buka agar tidak memuat angka sembarangan.
              Silakan pilih tipe motor pada daftar di atas atau muat file map untuk menampilkan tabel.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Presets */}
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4 lg:grid-cols-8">
              {PRESET_LIST.map((preset) => {
                const isAct = activePreset === preset.key;
                return (
                  <button
                    key={preset.key}
                    type="button"
                    onClick={() => onApplyPreset(preset.key)}
                    className={`min-h-[40px] rounded-md border px-2 py-2 text-xs font-bold transition-colors whitespace-nowrap ${
                      isAct
                        ? 'border-[#FF1E42] bg-[#FF1E42] text-white'
                        : 'border-slate-700 bg-[#090B10] text-slate-300 hover:border-slate-500 hover:text-white'
                    }`}
                  >
                    {preset.label}
                  </button>
                );
              })}
            </div>

            {/* Parameter & Subview Controls */}
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <div>
                <label htmlFor="select-map-mode" className="mb-1 block text-xs font-medium text-slate-300">
                  Parameter Peta
                </label>
                <select
                  id="select-map-mode"
                  value={activeParam}
                  onChange={(e) => onChangeParam(e.target.value as MapParameter)}
                  className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
                >
                  <option value="FUEL">Bahan Bakar (Fuel VE Table %)</option>
                  <option value="IGN">Pengapian (Ignition Timing °BTDC)</option>
                </select>
              </div>
              <div>
                <label htmlFor="select-sub-view" className="mb-1 block text-xs font-medium text-slate-300">
                  Tampilan Grafik
                </label>
                <select
                  id="select-sub-view"
                  value={subView}
                  onChange={(e) => onChangeSubView(e.target.value as MapSubView)}
                  className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
                >
                  <option value="TABLE">1. Tabel 2D (Klik 2x Edit)</option>
                  <option value="CURVE2D">2. Kurva 2D (Tarik Titik)</option>
                  <option value="SURFACE3D">3. Bukit 3D (360° Drag)</option>
                </select>
              </div>
            </div>

            {/* Selected cell readout */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-slate-800 bg-[#090B10] px-3 py-2 text-xs font-mono tabular-nums">
              <div className="flex items-center gap-2 text-slate-300">
                <Activity className="h-3.5 w-3.5 text-cyan-400" />
                <span>
                  Sel Aktif: <strong className="text-white">{rpmBins[selectedCell.r]} RPM</strong> · TPS{' '}
                  <strong className="text-white">{tpsBins[selectedCell.c]}%</strong>
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-cyan-400">
                  Nilai:{' '}
                  <strong>
                    {(currentMatrix[selectedCell.r]?.[selectedCell.c] ?? 0).toFixed(1)}
                    {activeParam === 'IGN' ? '°' : ' ms'}
                  </strong>
                </span>
                <button
                  type="button"
                  onClick={() =>
                    setEditingCell({
                      r: selectedCell.r,
                      c: selectedCell.c,
                      draft: String(currentMatrix[selectedCell.r]?.[selectedCell.c] ?? 0),
                    })
                  }
                  className="rounded border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-slate-100 hover:border-cyan-400"
                >
                  Ubah Nilai
                </button>
              </div>
            </div>

            {/* Inline editor bar when double-clicked or clicked "Ubah Nilai" */}
            {editingCell && (
              <div className="flex flex-wrap items-center gap-2 rounded-md border border-cyan-500/50 bg-[#0B1722] p-3">
                <span className="font-mono text-xs text-cyan-200 tabular-nums">
                  Edit @ {rpmBins[editingCell.r]} RPM, TPS {tpsBins[editingCell.c]}%:
                </span>
                <input
                  type="number"
                  step="0.1"
                  value={editingCell.draft}
                  onChange={(e) => setEditingCell({ ...editingCell, draft: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') commitInlineEdit();
                    if (e.key === 'Escape') setEditingCell(null);
                  }}
                  autoFocus
                  className="w-28 rounded border border-cyan-500 bg-[#090B10] px-2.5 py-1.5 font-mono text-sm text-white focus:outline-none"
                />
                <button
                  type="button"
                  onClick={commitInlineEdit}
                  className="rounded bg-cyan-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-cyan-400"
                >
                  Simpan
                </button>
                <button
                  type="button"
                  onClick={() => setEditingCell(null)}
                  className="rounded border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Batal
                </button>
              </div>
            )}

            {/* Subview 1: 2D Matrix Table */}
            {subView === 'TABLE' && (
              <div className="max-h-[420px] overflow-auto rounded-md border border-slate-800 bg-[#07090E]">
                <table className="border-separate border-spacing-[1.5px] text-center font-mono text-[11px] tabular-nums">
                  <thead>
                    <tr>
                      <th className="sticky top-0 left-0 z-30 min-w-[58px] border-b border-slate-700 bg-[#1A202E] px-2 py-2 text-cyan-400">
                        RPM \ TPS
                      </th>
                      {tpsBins.map((tps, c) => (
                        <th
                          key={c}
                          className="sticky top-0 z-20 min-w-[46px] border-b border-slate-700 bg-[#151A25] px-1.5 py-2 text-[#FF1E42]"
                        >
                          {tps}%
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rpmBins.map((rpm, r) => (
                      <tr key={r}>
                        <th className="sticky left-0 z-10 min-w-[58px] bg-[#171C28] px-2 py-1.5 text-cyan-300">
                          {rpm}
                        </th>
                        {tpsBins.map((_, c) => {
                          const val = currentMatrix[r]?.[c] ?? 0;
                          const norm = Math.max(
                            0,
                            Math.min(1, (val - (activeParam === 'IGN' ? 8 : 10)) / (activeParam === 'IGN' ? 28 : 12))
                          );
                          const isSelected = selectedCell.r === r && selectedCell.c === c;
                          return (
                            <td
                              key={c}
                              onClick={() => onSelectCell(r, c)}
                              onDoubleClick={() =>
                                setEditingCell({ r, c, draft: String(val) })
                              }
                              style={{
                                backgroundColor: `hsl(${(1 - norm) * 230}, 85%, 34%)`,
                              }}
                              className={`h-7 min-w-[44px] cursor-pointer px-1.5 font-semibold text-white transition-transform ${
                                isSelected ? 'outline-2 outline-amber-300 z-10 relative scale-[1.04]' : ''
                              }`}
                            >
                              {val.toFixed(1)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Subview 2: 2D Interactive Curve */}
            {subView === 'CURVE2D' && (
              <div className="space-y-1.5">
                <div className="text-xs text-slate-400">
                  Seret titik hijau/merah secara vertikal untuk mengubah nilai pada baris {rpmBins[selectedCell.r]} RPM.
                </div>
                <canvas
                  ref={canvas2DRef}
                  onPointerDown={handle2DPointerDown}
                  onPointerMove={handle2DPointerMove}
                  onPointerUp={handle2DPointerUp}
                  onPointerCancel={handle2DPointerUp}
                  className="block w-full cursor-crosshair touch-none rounded-md border border-slate-800 bg-[#07090E]"
                />
              </div>
            )}

            {/* Subview 3: 3D Surface */}
            {subView === 'SURFACE3D' && (
              <div className="space-y-1.5">
                <div className="text-xs text-slate-400">
                  Seret kanvas ke segala arah untuk memutar permukaan peta 3D secara interaktif.
                </div>
                <canvas
                  ref={canvas3DRef}
                  onPointerDown={(e) => {
                    rotRef.current.dragging = true;
                    rotRef.current.lastX = e.clientX;
                    rotRef.current.lastY = e.clientY;
                    e.currentTarget.setPointerCapture(e.pointerId);
                  }}
                  onPointerMove={(e) => {
                    if (!rotRef.current.dragging) return;
                    const dx = e.clientX - rotRef.current.lastX;
                    const dy = e.clientY - rotRef.current.lastY;
                    rotRef.current.lastX = e.clientX;
                    rotRef.current.lastY = e.clientY;
                    rotRef.current.z += dx * 0.01;
                    rotRef.current.x = Math.max(0.25, Math.min(1.45, rotRef.current.x + dy * 0.01));
                    draw3D();
                  }}
                  onPointerUp={() => {
                    rotRef.current.dragging = false;
                  }}
                  onPointerCancel={() => {
                    rotRef.current.dragging = false;
                  }}
                  className="block w-full cursor-grab touch-none rounded-md border border-slate-800 bg-[#07090E] active:cursor-grabbing"
                />
              </div>
            )}

            {/* Step & Interpolation Action Bar */}
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <button
                type="button"
                onClick={() => onAdjustSelectedCell(-1)}
                className="min-h-[44px] rounded-md border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-bold text-slate-100 transition-colors hover:border-slate-500 hover:bg-slate-800 whitespace-nowrap"
              >
                - 1 Step
              </button>
              <button
                type="button"
                onClick={() => onAdjustSelectedCell(1)}
                className="min-h-[44px] rounded-md border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-bold text-slate-100 transition-colors hover:border-slate-500 hover:bg-slate-800 whitespace-nowrap"
              >
                + 1 Step
              </button>
              <button
                type="button"
                onClick={onSmoothInterpolate}
                className="min-h-[44px] rounded-md bg-cyan-500 px-4 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-cyan-400 whitespace-nowrap"
              >
                Interpolasi Rata
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
