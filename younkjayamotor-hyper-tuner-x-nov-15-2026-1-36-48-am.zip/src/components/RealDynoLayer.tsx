import React, { useEffect, useRef } from 'react';
import { Play, Square, Download, TrendingUp } from 'lucide-react';
import type { DynoPoint } from '../types/ecu';

interface RealDynoLayerProps {
  dynoArmed: boolean;
  dynoHP: number;
  dynoTrq: number;
  currentRpm: number;
  dynoLog: DynoPoint[];
  onToggleDyno: () => void;
  onExportCsv: () => void;
}

export const RealDynoLayer: React.FC<RealDynoLayerProps> = ({
  dynoArmed,
  dynoHP,
  dynoTrq,
  currentRpm,
  dynoLog,
  onToggleDyno,
  onExportCsv,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const parentWidth = canvas.parentElement?.clientWidth || 640;
    canvas.width = parentWidth;
    canvas.height = 280;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = '#151B26';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 48) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 44) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // RPM axis ticks
    ctx.fillStyle = '#64748B';
    ctx.font = '10px "JetBrains Mono", monospace';
    for (let r = 2000; r <= 14000; r += 2000) {
      const rx = ((r - 1500) / 13500) * w;
      ctx.fillText(`${r}`, Math.max(4, Math.min(w - 36, rx - 12)), h - 8);
    }

    if (dynoLog.length > 0) {
      // Power HP (Crimson)
      ctx.strokeStyle = '#FF1E42';
      ctx.lineWidth = 3;
      ctx.beginPath();
      dynoLog.forEach((p, i) => {
        const x = ((p.r - 1500) / 13500) * w;
        const y = h - 20 - (p.hp / 26) * (h - 32);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      // Torque Nm (Cyan)
      ctx.strokeStyle = '#06B6D4';
      ctx.lineWidth = 3;
      ctx.beginPath();
      dynoLog.forEach((p, i) => {
        const x = ((p.r - 1500) / 13500) * w;
        const y = h - 20 - (p.trq / 22) * (h - 32);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }

    // Sweep Line (Amber/Gold)
    const sx = Math.max(2, Math.min(w - 2, ((currentRpm - 1500) / 13500) * w));
    ctx.strokeStyle = '#FACC15';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(sx, 0);
    ctx.lineTo(sx, h);
    ctx.stroke();
  }, [dynoLog, currentRpm, dynoHP, dynoTrq]);

  return (
    <div className="space-y-4">
      <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-[#FF1E42]" />
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              Virtual Dyno (Kalkulasi Inersia Nyata)
            </h2>
          </div>
          <span
            className={`font-mono text-xs font-semibold ${
              dynoArmed ? 'text-rose-400' : 'text-amber-400'
            }`}
          >
            {dynoArmed ? '● MEREKAM TARIKAN' : '■ STANDBY'}
          </span>
        </div>

        <canvas
          ref={canvasRef}
          className="block w-full rounded-md border border-slate-800 bg-[#07090E]"
        />

        {/* Readout Strip */}
        <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
          <div className="rounded-md border border-slate-800 bg-[#090B10] px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wider text-rose-400">
              POWER (PEAK / LIVE)
            </div>
            <div className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
              {dynoHP.toFixed(2)} <span className="text-xs font-normal text-slate-400">HP</span>
            </div>
          </div>

          <div className="rounded-md border border-slate-800 bg-[#090B10] px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wider text-cyan-400">
              TORSI (TORQUE)
            </div>
            <div className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
              {dynoTrq.toFixed(2)} <span className="text-xs font-normal text-slate-400">Nm</span>
            </div>
          </div>

          <div className="rounded-md border border-slate-800 bg-[#090B10] px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wider text-amber-400">
              SWEEP RPM
            </div>
            <div className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
              {currentRpm} <span className="text-xs font-normal text-slate-400">RPM</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <button
            type="button"
            onClick={onToggleDyno}
            className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-md px-4 py-2.5 text-sm font-bold transition-colors whitespace-nowrap ${
              dynoArmed
                ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                : 'bg-[#FF1E42] text-white hover:bg-[#e11637]'
            }`}
          >
            {dynoArmed ? (
              <>
                <Square className="h-4 w-4" />
                Stop Dyno
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                Mulai Tarikan Dyno Nyata
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onExportCsv}
            className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-md border border-slate-700 bg-slate-900 px-4 py-2.5 text-sm font-semibold text-slate-100 transition-colors hover:border-slate-500 hover:bg-slate-800 whitespace-nowrap"
          >
            <Download className="h-4 w-4" />
            Export CSV ({dynoLog.length} Sampel)
          </button>
        </div>
      </section>
    </div>
  );
};
