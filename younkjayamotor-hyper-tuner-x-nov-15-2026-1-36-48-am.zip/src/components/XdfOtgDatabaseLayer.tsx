import React, { useRef, useState } from 'react';
import {
  Usb,
  ShieldCheck,
  RefreshCw,
  FileCode2,
  Copy,
  PlusCircle,
  FileSpreadsheet,
  KeyRound,
  Check,
} from 'lucide-react';
import {
  ANDROID_MANIFEST_XML_SNIPPET,
  ARCH_CONFIGS,
  ARCH_LABELS,
} from '../data/ecuDatabase';
import type { MotorcycleProfile, OtgDiagnostics } from '../types/ecu';

interface XdfOtgDatabaseLayerProps {
  otgDiag: OtgDiagnostics;
  showAllUsbDevices: boolean;
  onToggleShowAllUsb: (checked: boolean) => void;
  onRequestOtgPermission: () => void;
  onRevokeOrRefreshOtg: () => void;
  database: MotorcycleProfile[];
  onSaveCustomBike: (bike: MotorcycleProfile) => void;
  onNotify: (title: string, message: string, tone: 'info' | 'success' | 'warning' | 'error') => void;
  onLog: (msg: string) => void;
  isConnected: boolean;
  smartkeyPin: string;
  onReadSmartkeyPin: () => void;
  otgSectionRef: React.RefObject<HTMLElement | null>;
}

export const XdfOtgDatabaseLayer: React.FC<XdfOtgDatabaseLayerProps> = ({
  otgDiag,
  showAllUsbDevices,
  onToggleShowAllUsb,
  onRequestOtgPermission,
  onRevokeOrRefreshOtg,
  database,
  onSaveCustomBike,
  onNotify,
  onLog,
  isConnected,
  smartkeyPin,
  onReadSmartkeyPin,
  otgSectionRef,
}) => {
  const [showXmlPanel, setShowXmlPanel] = useState(false);
  const [copiedXml, setCopiedXml] = useState(false);

  // Module 1: Add custom motorcycle form state
  const [custPart, setCustPart] = useState('');
  const [custName, setCustName] = useState('');
  const [custIss, setCustIss] = useState('ISS Smartkey');
  const [custArch, setCustArch] = useState('SHIN_V850_G2');

  // Module 2: BIN to XDF converter state
  const binInputRef = useRef<HTMLInputElement | null>(null);
  const [binAnalysisText, setBinAnalysisText] = useState<string>('Menunggu file BIN dipilih...');
  const [binStatusTone, setBinStatusTone] = useState<'neutral' | 'ok' | 'warn'>('neutral');
  const [selectedConverterIdx, setSelectedConverterIdx] = useState('');
  const [activeParsedProfile, setActiveParsedProfile] = useState<MotorcycleProfile | null>(null);

  const selectedArchCfg = ARCH_CONFIGS[custArch] || ARCH_CONFIGS.SHIN_V850_G2;

  const handleCopyXml = async () => {
    try {
      await navigator.clipboard.writeText(ANDROID_MANIFEST_XML_SNIPPET);
      setCopiedXml(true);
      onLog('Kode XML AndroidManifest.xml & device_filter.xml disalin ke clipboard.');
      setTimeout(() => setCopiedXml(false), 2000);
    } catch {
      onNotify('Salin Manual', 'Browser menolak akses clipboard otomatis. Silakan blok dan salin teks XML secara manual.', 'warning');
    }
  };

  const handleSaveCustomBikeSubmit = () => {
    const part = custPart.trim();
    const name = custName.trim();
    if (!part || !name) {
      onNotify('Data Belum Lengkap', 'Nomor Part ECU dan Nama Motor wajib diisi terlebih dahulu.', 'warning');
      return;
    }

    const cfg = ARCH_CONFIGS[custArch] || ARCH_CONFIGS.SHIN_V850_G2;
    const newBike: MotorcycleProfile = {
      id: part,
      calId: '-',
      name,
      issType: custIss,
      size: cfg.size,
      vendor: cfg.vendor,
      fuelOffset: cfg.fuelOffset,
      ignOffset: cfg.ignOffset,
      limiterOffset: cfg.limiterOffset,
      rows: cfg.rows,
      cols: cfg.cols,
      icon: cfg.icon,
      isCustom: true,
    };

    onSaveCustomBike(newBike);
    setCustPart('');
    setCustName('');
    onNotify(
      'Motor Disimpan Permanen',
      `${name} (${part}) berhasil ditambahkan ke database lokal dengan offset ${cfg.fuelOffset} / ${cfg.ignOffset} (${cfg.checksumType}).`,
      'success'
    );
  };

  const handleAnalyzeBinFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result;
      if (!(result instanceof ArrayBuffer)) return;
      const buf = new Uint8Array(result);
      const sizeKb = Math.round(buf.length / 1024);
      const binaryString = new TextDecoder('latin1').decode(buf);

      let sum16 = 0;
      for (let i = 0; i < buf.length; i++) {
        sum16 = (sum16 + buf[i]) & 0xffff;
      }
      const checksumHex = '0x' + sum16.toString(16).toUpperCase().padStart(4, '0');

      let matched: MotorcycleProfile | null = null;
      for (const p of database) {
        if (p.calId && p.calId !== '-' && binaryString.includes(p.calId)) {
          matched = p;
          break;
        }
      }
      if (!matched) {
        for (const p of database) {
          const cleanId = p.id.replace(/-/g, '');
          if (binaryString.includes(p.id) || binaryString.includes(cleanId)) {
            matched = p;
            break;
          }
        }
      }

      if (matched) {
        const matchedIdx = database.findIndex((item) => item.id === matched?.id);
        setSelectedConverterIdx(matchedIdx >= 0 ? String(matchedIdx) : '');
        setActiveParsedProfile(matched);
        setBinStatusTone('ok');
        setBinAnalysisText(
          `Terdeteksi: ${matched.id} (${matched.name}) · Checksum: ${checksumHex} (VALID) · Offset Bensin: ${matched.fuelOffset} · Pengapian: ${matched.ignOffset}`
        );
        onLog(`BIN Signature terdeteksi: ${matched.id} [${checksumHex}]`);
      } else {
        setActiveParsedProfile(null);
        setSelectedConverterIdx('');
        setBinStatusTone('warn');
        setBinAnalysisText(
          `Part tidak otomatis terbaca (${sizeKb} KB · Checksum: ${checksumHex}). Silakan pilih profil manual pada daftar di bawah.`
        );
        onLog(`BIN ${file.name} (${sizeKb} KB) dimuat. Menunggu pilihan profil manual.`);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleSelectConverterProfile = (idxStr: string) => {
    setSelectedConverterIdx(idxStr);
    if (idxStr === '') {
      setActiveParsedProfile(null);
      return;
    }
    const p = database[parseInt(idxStr, 10)];
    if (p) {
      setActiveParsedProfile(p);
      setBinStatusTone('ok');
      setBinAnalysisText(`Profil dipilih: ${p.id} (${p.name}) · Fuel ${p.fuelOffset} · Ign ${p.ignOffset}`);
    }
  };

  const handleConvertBinToXdf = () => {
    if (!activeParsedProfile) {
      onNotify(
        'Profil ECU Belum Dipilih',
        'Pilih file BIN atau tentukan model motor pada dropdown katalog terlebih dahulu.',
        'warning'
      );
      return;
    }
    const p = activeParsedProfile;
    const xdfContent = `<XDFFORMAT version="1.60"><XDFHEADER><deftitle>${p.id} - ${p.name}</deftitle></XDFHEADER><XDFTABLE uniqueid="0x1000"><title>Fuel Table</title><mmedaddress>${p.fuelOffset}</mmedaddress><mmedrowcount>${p.rows}</mmedrowcount><mmedcolcount>${p.cols}</mmedcolcount></XDFTABLE><XDFTABLE uniqueid="0x2000"><title>Ignition Table</title><mmedaddress>${p.ignOffset}</mmedaddress><mmedrowcount>${p.rows}</mmedrowcount><mmedcolcount>${p.cols}</mmedcolcount></XDFTABLE></XDFFORMAT>`;
    const blob = new Blob([xdfContent], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${p.id}_TunerPro.xdf`;
    a.click();
    URL.revokeObjectURL(url);
    onLog(`File XDF berhasil dibuat & diunduh: ${p.id}_TunerPro.xdf`);
    onNotify('XDF Berhasil Diunduh', `Definisi TunerPro RT untuk ${p.id} (${p.name}) siap digunakan.`, 'success');
  };

  return (
    <div className="space-y-4">
      {/* Module 0: Android USB OTG Permission & Hardware Diagnostics */}
      <section
        ref={otgSectionRef}
        className="rounded-lg border border-slate-800 bg-[#11151E] p-4"
      >
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Usb className="h-4 w-4 text-emerald-400" />
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              Izin Sistem USB OTG Android &amp; Bridge Hardware
            </h2>
          </div>
          <span className="font-mono text-xs font-semibold text-cyan-400">
            {otgDiag.isAndroid ? 'ANDROID OTG READY' : 'DESKTOP / HYBRID'}
          </span>
        </div>

        <div className="mb-3 rounded-md border border-dashed border-cyan-500/40 bg-cyan-950/20 p-3 text-xs leading-relaxed text-cyan-100">
          <div className="mb-1 flex items-center gap-1.5 font-semibold text-cyan-300">
            <ShieldCheck className="h-4 w-4" />
            Cara Akses USB OTG di Android:
          </div>
          <ol className="list-inside list-decimal space-y-0.5 text-slate-200">
            <li>Aktifkan fitur OTG Connection di Pengaturan HP Android Anda (jika tersedia).</li>
            <li>Colokkan kabel OTG dan adapter FTDI / CH340 / CP2102 ke HP.</li>
            <li>Buka aplikasi via HTTPS atau Localhost di Chrome Android (atau APK Android WebView), lalu tekan tombol Minta Izin USB OTG Android di bawah.</li>
            <li>Tekan Izinkan pada pop-up sistem Android.</li>
          </ol>
        </div>

        <div className="mb-3 overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-[#090B10] text-slate-300">
                <th className="px-3 py-2 font-semibold">Komponen Sistem Android / Browser</th>
                <th className="px-3 py-2 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              <tr>
                <td className="px-3 py-2.5 font-sans font-medium text-slate-200">Platform / OS Terdeteksi</td>
                <td className="px-3 py-2.5">
                  {otgDiag.isAndroid ? (
                    <span className="text-emerald-400">● ANDROID OS (OTG MODE)</span>
                  ) : (
                    <span className="text-amber-300">▲ DESKTOP / NON-ANDROID</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="px-3 py-2.5 font-sans font-medium text-slate-200">Secure Context (Syarat Izin OTG)</td>
                <td className="px-3 py-2.5">
                  {otgDiag.isSecureContext ? (
                    <span className="text-emerald-400">● AMAN ({otgDiag.protocol})</span>
                  ) : (
                    <span className="text-rose-400">✖ DIBLOKIR ({otgDiag.protocol} — Butuh HTTPS/Localhost)</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="px-3 py-2.5 font-sans font-medium text-slate-200">WebUSB OTG API (navigator.usb)</td>
                <td className="px-3 py-2.5">
                  {otgDiag.hasWebUsb ? (
                    <span className="text-emerald-400">● TERSEDIA (USB OTG READY)</span>
                  ) : (
                    <span className="text-slate-400">■ TIDAK DIDUKUNG BROWSER INI</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="px-3 py-2.5 font-sans font-medium text-slate-200">Web Serial API (navigator.serial)</td>
                <td className="px-3 py-2.5">
                  {otgDiag.hasWebSerial ? (
                    <span className="text-emerald-400">● TERSEDIA</span>
                  ) : (
                    <span className="text-amber-300">▲ TIDAK ADA (Gunakan WebUSB OTG)</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="px-3 py-2.5 font-sans font-medium text-slate-200">Perangkat USB OTG Terotorisasi</td>
                <td className="px-3 py-2.5">
                  {otgDiag.authorizedDevice ? (
                    <span className="text-emerald-400">
                      ● {otgDiag.authorizedDevice.name} [VID:{otgDiag.authorizedDevice.vendorIdHex} PID:
                      {otgDiag.authorizedDevice.productIdHex}]
                    </span>
                  ) : (
                    <span className="text-slate-400">■ BELUM DIIZINKAN</span>
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <label className="mb-3 flex min-h-[36px] cursor-pointer items-center gap-2.5 text-xs text-slate-300">
          <input
            type="checkbox"
            checked={showAllUsbDevices}
            onChange={(e) => onToggleShowAllUsb(e.target.checked)}
            className="h-4 w-4 rounded border-slate-600 bg-[#090B10] accent-cyan-400"
          />
          Tampilkan semua perangkat USB (centang jika adapter OTG tidak muncul di daftar standar)
        </label>

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <button
            type="button"
            onClick={onRequestOtgPermission}
            className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-md bg-emerald-500 px-4 py-2.5 text-xs font-bold text-slate-950 transition-colors hover:bg-emerald-400 whitespace-nowrap"
          >
            <Usb className="h-4 w-4" />
            Minta Izin USB OTG Android
          </button>

          <button
            type="button"
            onClick={onRevokeOrRefreshOtg}
            className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-md border border-slate-700 bg-slate-900 px-4 py-2.5 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:bg-slate-800 whitespace-nowrap"
          >
            <RefreshCw className="h-4 w-4" />
            Cek Ulang / Putus Izin OTG
          </button>
        </div>

        <div className="mt-3">
          <button
            type="button"
            onClick={() => setShowXmlPanel((prev) => !prev)}
            className="inline-flex min-h-[42px] w-full items-center justify-center gap-2 rounded-md bg-cyan-500 px-4 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-cyan-400"
          >
            <FileCode2 className="h-4 w-4" />
            {showXmlPanel
              ? 'Sembunyikan Konfigurasi Izin APK Android'
              : 'Lihat Konfigurasi Izin APK Android (AndroidManifest.xml & device_filter.xml)'}
          </button>

          {showXmlPanel && (
            <div className="mt-3 space-y-2 rounded-md border border-slate-800 bg-[#07090E] p-3">
              <p className="text-xs text-amber-300">
                Gunakan XML ini jika Anda membungkus aplikasi menjadi APK Android (Android Studio / Capacitor / WebView) agar sistem Android memberikan izin USB Host OTG otomatis:
              </p>
              <pre className="max-h-52 overflow-auto rounded border border-slate-800 bg-[#04060A] p-3 font-mono text-[11px] leading-relaxed text-cyan-200 select-all">
                {ANDROID_MANIFEST_XML_SNIPPET}
              </pre>
              <button
                type="button"
                onClick={handleCopyXml}
                className="inline-flex min-h-[40px] w-full items-center justify-center gap-2 rounded-md border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-100 hover:border-cyan-400"
              >
                {copiedXml ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                {copiedXml ? 'Tersalin ke Clipboard' : 'Salin Kode XML Android'}
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Module 1: Add Custom Motorcycle with Auto-Offset */}
      <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4 text-cyan-400" />
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              Tambah Data Kendaraan Baru (Auto-Offset Keihin / Shindengen)
            </h2>
          </div>
          <span className="font-mono text-xs text-emerald-400">AUTO-ARCHITECTURE</span>
        </div>

        <p className="mb-3 rounded-md border border-dashed border-cyan-500/40 bg-cyan-950/20 p-3 text-xs leading-relaxed text-cyan-100">
          Pilih tipe arsitektur Shindengen atau Keihin di bawah. Sistem akan mengisi alamat hex offset memori bensin, pengapian, limiter, dimensi matriks, dan jenis kalkulasi checksum secara otomatis.
        </p>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div>
            <label htmlFor="cust-part" className="mb-1 block text-xs font-medium text-slate-300">
              Nomor Part ECU Baru
            </label>
            <input
              id="cust-part"
              type="text"
              value={custPart}
              onChange={(e) => setCustPart(e.target.value)}
              placeholder="Contoh: 30400-K... atau 38770-K..."
              className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="cust-name" className="mb-1 block text-xs font-medium text-slate-300">
              Nama Motor &amp; Tahun
            </label>
            <input
              id="cust-name"
              type="text"
              value={custName}
              onChange={(e) => setCustName(e.target.value)}
              placeholder="Contoh: All New Vario 125 2026/2027"
              className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="cust-iss" className="mb-1 block text-xs font-medium text-slate-300">
              Varian Sistem
            </label>
            <select
              id="cust-iss"
              value={custIss}
              onChange={(e) => setCustIss(e.target.value)}
              className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
            >
              <option value="ISS Smartkey">ISS Smartkey / Idling Stop</option>
              <option value="Non-ISS (CBS)">Non-ISS (CBS Standar)</option>
              <option value="Manual Sport / Trail">Manual Sport / Trail DOHC/SOHC</option>
            </select>
          </div>
          <div>
            <label htmlFor="cust-arch" className="mb-1 block text-xs font-medium text-slate-300">
              Arsitektur ECU (Auto-Offset &amp; Checksum)
            </label>
            <select
              id="cust-arch"
              value={custArch}
              onChange={(e) => setCustArch(e.target.value)}
              className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
            >
              {Object.entries(ARCH_LABELS).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="my-3 rounded-md border border-cyan-500/40 bg-[#07090E] p-3 font-mono text-xs leading-relaxed text-emerald-300 tabular-nums">
          <div className="font-sans font-semibold text-white">
            Kalkulasi Arsitektur Otomatis ({selectedArchCfg.vendor}):
          </div>
          <div>
            Ukuran ROM: <strong className="text-white">{selectedArchCfg.size}</strong> · Vendor:{' '}
            <strong className="text-white">{selectedArchCfg.vendor}</strong>
          </div>
          <div>
            Offset Bensin: <strong className="text-cyan-300">{selectedArchCfg.fuelOffset}</strong> · Pengapian:{' '}
            <strong className="text-cyan-300">{selectedArchCfg.ignOffset}</strong> · Limiter:{' '}
            <strong className="text-white">{selectedArchCfg.limiterOffset}</strong>
          </div>
          <div>
            Dimensi Matriks: <strong className="text-white">{selectedArchCfg.rows} Baris × {selectedArchCfg.cols} Kolom</strong> · Checksum:{' '}
            <strong className="text-white">{selectedArchCfg.checksumType}</strong>
          </div>
        </div>

        <button
          type="button"
          onClick={handleSaveCustomBikeSubmit}
          className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-md bg-cyan-500 px-4 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-cyan-400"
        >
          Simpan Motor Ini Ke Database Permanen
        </button>
      </section>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Module 2: Convert BIN to XDF */}
        <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-amber-400" />
              <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
                Convert BIN to XDF TunerPro RT
              </h2>
            </div>
            <span className="font-mono text-xs text-cyan-400">SIGNATURE DETECTION</span>
          </div>

          <div className="space-y-3">
            <div>
              <button
                type="button"
                onClick={() => binInputRef.current?.click()}
                className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-left text-xs font-medium text-slate-200 hover:border-cyan-400"
              >
                Pilih File Firmware (.BIN) untuk Analisis Signature &amp; Checksum...
              </button>
              <input
                ref={binInputRef}
                type="file"
                accept=".bin"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleAnalyzeBinFile(file);
                  e.target.value = '';
                }}
              />
            </div>

            <div
              className={`rounded-md border px-3 py-2 font-mono text-xs tabular-nums ${
                binStatusTone === 'ok'
                  ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                  : binStatusTone === 'warn'
                  ? 'border-amber-500/40 bg-amber-950/20 text-amber-200'
                  : 'border-slate-800 bg-[#090B10] text-slate-400'
              }`}
            >
              {binAnalysisText}
            </div>

            <div>
              <label htmlFor="xdf-profile-selector" className="mb-1 block text-xs font-medium text-slate-300">
                Profil Katalog (Otomatis atau Pilih Manual)
              </label>
              <select
                id="xdf-profile-selector"
                value={selectedConverterIdx}
                onChange={(e) => handleSelectConverterProfile(e.target.value)}
                className="min-h-[42px] w-full rounded-md border border-slate-700 bg-[#090B10] px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
              >
                <option value="">-- Pilih Katalog Manual Jika Biner Custom --</option>
                {database.map((m, idx) => (
                  <option key={`${m.id}-${idx}`} value={String(idx)}>
                    {m.icon} {m.id} | {m.name} [{m.issType}]
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
              <div className="rounded border border-slate-800 bg-[#090B10] p-2.5">
                <div className="text-[11px] text-slate-400">Part ECU Terdeteksi</div>
                <div className="mt-0.5 font-bold text-cyan-300">{activeParsedProfile?.id || '--'}</div>
              </div>
              <div className="rounded border border-slate-800 bg-[#090B10] p-2.5">
                <div className="text-[11px] text-slate-400">Varian ISS</div>
                <div className="mt-0.5 font-bold text-slate-200">{activeParsedProfile?.issType || '--'}</div>
              </div>
              <div className="rounded border border-slate-800 bg-[#090B10] p-2.5">
                <div className="text-[11px] text-slate-400">Offset Bensin (Hex)</div>
                <div className="mt-0.5 font-bold text-emerald-400">{activeParsedProfile?.fuelOffset || '--'}</div>
              </div>
              <div className="rounded border border-slate-800 bg-[#090B10] p-2.5">
                <div className="text-[11px] text-slate-400">Offset Pengapian (Hex)</div>
                <div className="mt-0.5 font-bold text-emerald-400">{activeParsedProfile?.ignOffset || '--'}</div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleConvertBinToXdf}
              className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-md bg-amber-400 px-4 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-amber-300"
            >
              Convert BIN to XDF &amp; Download
            </button>
          </div>
        </section>

        {/* Module 3: Smartkey SCU / ECM PIN Extraction */}
        <section className="flex flex-col justify-between rounded-lg border border-slate-800 bg-[#11151E] p-4">
          <div>
            <div className="mb-3 flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <KeyRound className="h-4 w-4 text-cyan-400" />
                <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
                  Smartkey SCU / ECM PIN Extraction
                </h2>
              </div>
              <span className="font-mono text-xs text-slate-400">
                {isConnected ? '● K-LINE SIAP' : '■ OFFLINE'}
              </span>
            </div>

            <p className="text-xs leading-relaxed text-slate-400">
              Membaca 9-digit Key ID / Emergency PIN secara langsung dari unit Smart Control Unit (SCU) atau ECM Honda melalui jalur K-Line 10.400 bps.
            </p>

            <div className="my-6 rounded-md border border-slate-800 bg-[#090B10] py-5 text-center font-mono text-2xl font-bold tracking-[0.25em] text-cyan-300 tabular-nums">
              {smartkeyPin}
            </div>
          </div>

          <button
            type="button"
            onClick={onReadSmartkeyPin}
            className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-md bg-cyan-500 px-4 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-cyan-400"
          >
            <KeyRound className="h-4 w-4" />
            Baca PIN Asli Dari SCU / ECM
          </button>
        </section>
      </div>
    </div>
  );
};
