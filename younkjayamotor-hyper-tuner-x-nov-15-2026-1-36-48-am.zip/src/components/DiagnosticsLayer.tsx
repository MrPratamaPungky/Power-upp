import React from 'react';
import { Zap, Gauge } from 'lucide-react';
import type { SensorTelemetry, SwitchStates } from '../types/ecu';

interface DiagnosticsLayerProps {
  isConnected: boolean;
  switches: SwitchStates;
  telemetry: SensorTelemetry;
  activeRelayTest: { type: 'FP' | 'ST'; secondsLeft: number } | null;
  onTestRelay: (type: 'FP' | 'ST', seconds: number) => void;
}

export const DiagnosticsLayer: React.FC<DiagnosticsLayerProps> = ({
  isConnected,
  switches,
  telemetry,
  activeRelayTest,
  onTestRelay,
}) => {
  const renderSwitchStatus = (val: boolean | null) => {
    if (!isConnected || val === null) {
      return <span className="font-mono text-xs font-semibold text-slate-500">■ OFFLINE</span>;
    }
    return val ? (
      <span className="font-mono text-xs font-semibold text-emerald-400">● AKTIF (ON)</span>
    ) : (
      <span className="font-mono text-xs font-semibold text-slate-300">○ STANDBY (OFF)</span>
    );
  };

  const sensorRows = [
    {
      label: 'Engine RPM',
      value: isConnected && telemetry.rpm !== null ? `${telemetry.rpm} RPM` : '-- RPM',
      refRange: '1.400 - 1.600 RPM',
      ok: isConnected && telemetry.rpm !== null ? telemetry.rpm >= 1200 && telemetry.rpm <= 1800 : null,
    },
    {
      label: 'Bukaan Gas (TPS)',
      value: isConnected && telemetry.tps !== null ? `${telemetry.tps.toFixed(1)} %` : '-- %',
      refRange: '0.0% (Tutup) | 100% (WOT)',
      ok: isConnected && telemetry.tps !== null ? telemetry.tps >= 0 && telemetry.tps <= 100 : null,
    },
    {
      label: 'Injektor (ms)',
      value: isConnected && telemetry.inj !== null ? `${telemetry.inj.toFixed(2)} ms` : '-- ms',
      refRange: '1.80 - 2.60 ms (Idle)',
      ok: isConnected && telemetry.inj !== null ? telemetry.inj >= 1.5 && telemetry.inj <= 3.2 : null,
    },
    {
      label: 'Katup IACV',
      value: isConnected && telemetry.iacv !== null ? `${telemetry.iacv} Step` : '-- Step',
      refRange: '20 - 45 Steps',
      ok: isConnected && telemetry.iacv !== null ? telemetry.iacv >= 15 && telemetry.iacv <= 55 : null,
    },
    {
      label: 'MAP Sensor',
      value: isConnected && telemetry.map !== null ? `${telemetry.map} kPa` : '-- kPa',
      refRange: '25 - 40 kPa (Vakum)',
      ok: isConnected && telemetry.map !== null ? telemetry.map >= 20 && telemetry.map <= 105 : null,
    },
    {
      label: 'Ignition Timing',
      value: isConnected && telemetry.ign !== null ? `${telemetry.ign.toFixed(1)} °` : '-- °',
      refRange: '8.0° - 15.0° (Idle)',
      ok: isConnected && telemetry.ign !== null ? telemetry.ign >= 5 && telemetry.ign <= 40 : null,
    },
    {
      label: 'Suhu Pendingin (ECT)',
      value: isConnected && telemetry.ect !== null ? `${telemetry.ect} °C` : '-- °C',
      refRange: '80 - 95 °C',
      ok: isConnected && telemetry.ect !== null ? telemetry.ect <= 105 : null,
    },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Digital Switches */}
        <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
          <div className="mb-3 border-b border-slate-800 pb-2.5">
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              Status Saklar Digital Input
            </h2>
            <p className="text-xs text-slate-400">
              Pembacaan status real-time dari saklar pengaman dan starter motor.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            <div className="flex items-center justify-between rounded-md border border-slate-800 bg-[#090B10] px-3.5 py-3">
              <span className="text-xs font-semibold text-slate-200">Standar Samping</span>
              {renderSwitchStatus(switches.stand)}
            </div>
            <div className="flex items-center justify-between rounded-md border border-slate-800 bg-[#090B10] px-3.5 py-3">
              <span className="text-xs font-semibold text-slate-200">Rem Depan</span>
              {renderSwitchStatus(switches.brakeFront)}
            </div>
            <div className="flex items-center justify-between rounded-md border border-slate-800 bg-[#090B10] px-3.5 py-3">
              <span className="text-xs font-semibold text-slate-200">Rem Belakang</span>
              {renderSwitchStatus(switches.brakeRear)}
            </div>
            <div className="flex items-center justify-between rounded-md border border-slate-800 bg-[#090B10] px-3.5 py-3">
              <span className="text-xs font-semibold text-slate-200">Tombol Starter</span>
              {renderSwitchStatus(switches.starter)}
            </div>
          </div>
        </section>

        {/* Relay Actuator Tests */}
        <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
          <div className="mb-3 flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div>
              <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
                Uji Relay Aktuator 3 Detik (Mode 0x30)
              </h2>
              <p className="text-xs text-slate-400">
                Mengirim perintah aktivasi aktuator K-Line selama 3 detik.
              </p>
            </div>
            <Zap className="h-4 w-4 text-cyan-400" />
          </div>

          <div className="space-y-2.5">
            <div className="flex items-center justify-between gap-3 rounded-md border border-slate-800 bg-[#090B10] p-3">
              <div>
                <div className="text-sm font-semibold text-slate-100">Pompa Bensin (Fuel Pump)</div>
                <div className="text-xs text-slate-400">Mengaktifkan dengung pompa 3 detik</div>
              </div>
              <button
                type="button"
                disabled={activeRelayTest !== null}
                onClick={() => onTestRelay('FP', 3)}
                className="min-h-[40px] rounded-md bg-cyan-500 px-3.5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {activeRelayTest?.type === 'FP'
                  ? `Aktif (${activeRelayTest.secondsLeft}d)`
                  : 'Uji Relay'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-3 rounded-md border border-slate-800 bg-[#090B10] p-3">
              <div>
                <div className="text-sm font-semibold text-slate-100">Relay Starter ACG</div>
                <div className="text-xs text-slate-400">Menguji induksi starter motor</div>
              </div>
              <button
                type="button"
                disabled={activeRelayTest !== null}
                onClick={() => onTestRelay('ST', 3)}
                className="min-h-[40px] rounded-md bg-cyan-500 px-3.5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {activeRelayTest?.type === 'ST'
                  ? `Aktif (${activeRelayTest.secondsLeft}d)`
                  : 'Uji Relay'}
              </button>
            </div>
          </div>
        </section>
      </div>

      {/* Sensor Telemetry Table */}
      <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
        <div className="mb-3 flex items-center justify-between border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Gauge className="h-4 w-4 text-[#FF1E42]" />
            <h2 className="font-[var(--font-display)] text-sm font-bold tracking-wide text-slate-100">
              Data Sensor &amp; Parameter Pembanding Standar
            </h2>
          </div>
          <span className="font-mono text-xs text-slate-400">
            {isConnected ? '● STREAM K-LINE AKTIF' : '■ MENUNGGU KONEKSI ECU'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-[#090B10] text-slate-300">
                <th className="px-3 py-2.5 font-semibold">Sensor</th>
                <th className="px-3 py-2.5 font-semibold">Nilai Aktual</th>
                <th className="px-3 py-2.5 font-semibold">Acuan Standar</th>
                <th className="px-3 py-2.5 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono tabular-nums">
              {sensorRows.map((row) => (
                <tr key={row.label} className="hover:bg-slate-900/50">
                  <td className="px-3 py-2.5 font-sans font-semibold text-slate-100">{row.label}</td>
                  <td className="px-3 py-2.5 font-bold text-cyan-300">{row.value}</td>
                  <td className="px-3 py-2.5 text-slate-400">{row.refRange}</td>
                  <td className="px-3 py-2.5">
                    {row.ok === null ? (
                      <span className="text-slate-500">■ OFFLINE</span>
                    ) : row.ok ? (
                      <span className="text-emerald-400">● NORMAL</span>
                    ) : (
                      <span className="text-amber-400">▲ PERIKSA</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
