import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Usb,
  Search,
  Wrench,
  Activity,
  TrendingUp,
  Sliders,
  Bluetooth,
  Wifi,
  Cpu,
  X,
  AlertTriangle,
  CheckCircle2,
  Info,
} from 'lucide-react';
import {
  getMergedMotorcycleDatabase,
  saveCustomMotorcycleToStorage,
} from './data/ecuDatabase';
import {
  USB_OTG_FILTERS,
  WebUSBSerialDriver,
  bytesToHex,
  formatUsbDeviceInfo,
  getUsbChipName,
  inspectOtgDiagnostics,
  isAndroidDevice,
  KLINE_PACKETS,
  type TransportBridge,
} from './services/usbOtgDriver';
import type {
  AppNotice,
  DynoPoint,
  LayerId,
  MapParameter,
  MapSubView,
  MotorcycleProfile,
  OtgDiagnostics,
  PresetKey,
  SensorTelemetry,
  SwitchStates,
  TransportMode,
} from './types/ecu';
import { TunerDeckLayer } from './components/TunerDeckLayer';
import { DiagnosticsLayer } from './components/DiagnosticsLayer';
import { RealDynoLayer } from './components/RealDynoLayer';
import { XdfOtgDatabaseLayer } from './components/XdfOtgDatabaseLayer';

function generateBaseMatrices(rows: number, cols: number) {
  const rpmBins: number[] = [];
  for (let r = 0; r < rows; r++) {
    rpmBins.push(Math.round(800 + (r * 12500) / Math.max(1, rows - 1)));
  }
  const tpsBins: number[] = [];
  for (let c = 0; c < cols; c++) {
    tpsBins.push(parseFloat(((c * 100) / Math.max(1, cols - 1)).toFixed(1)));
  }

  const fuelMap: number[][] = [];
  const ignMap: number[][] = [];
  for (let r = 0; r < rows; r++) {
    fuelMap[r] = [];
    ignMap[r] = [];
    for (let c = 0; c < cols; c++) {
      fuelMap[r][c] = parseFloat((12.0 + c * 0.15 + r * 0.1).toFixed(1));
      ignMap[r][c] = parseFloat((10.0 + c * 0.8 + r * 0.4).toFixed(1));
    }
  }
  return { rpmBins, tpsBins, fuelMap, ignMap };
}

export default function App() {
  const [activeLayer, setActiveLayer] = useState<LayerId>(1);
  const [activeInterface, setActiveInterface] = useState<TransportMode>('SERIAL');
  const [isConnected, setIsConnected] = useState(false);
  const [connStatusText, setConnStatusText] = useState('TERPUTUS (OFFLINE)');
  const [connTone, setConnTone] = useState<'offline' | 'online' | 'fail'>('offline');

  // Hardware refs
  const bridgeRef = useRef<TransportBridge | null>(null);
  const serialPortRef = useRef<SerialPort | null>(null);
  const serialWriterRef = useRef<WritableStreamDefaultWriter<Uint8Array> | null>(null);
  const serialReaderRef = useRef<ReadableStreamDefaultReader<Uint8Array> | null>(null);
  const usbDeviceRef = useRef<USBDevice | null>(null);
  const otgSectionRef = useRef<HTMLElement | null>(null);

  // Android OTG Diagnostics
  const [otgDiag, setOtgDiag] = useState<OtgDiagnostics>({
    isAndroid: isAndroidDevice(),
    isSecureContext: typeof window !== 'undefined' ? window.isSecureContext : false,
    protocol: typeof location !== 'undefined' ? location.protocol : 'https:',
    hasWebUsb: typeof navigator !== 'undefined' && 'usb' in navigator,
    hasWebSerial: typeof navigator !== 'undefined' && 'serial' in navigator,
    authorizedDevice: null,
  });
  const [showAllUsbDevices, setShowAllUsbDevices] = useState(false);

  // ECU Database & Tuner Deck State
  const [database, setDatabase] = useState<MotorcycleProfile[]>(() => getMergedMotorcycleDatabase());
  const [selectedBikeIndex, setSelectedBikeIndex] = useState('');
  const [isTableLoaded, setIsTableLoaded] = useState(false);
  const [activeBikeBanner, setActiveBikeBanner] = useState<{
    name: string;
    details: string;
    icon: string;
  } | null>(null);

  const [rows, setRows] = useState(16);
  const [cols, setCols] = useState(16);
  const [rpmBins, setRpmBins] = useState<number[]>([]);
  const [tpsBins, setTpsBins] = useState<number[]>([]);
  const [fuelMap, setFuelMap] = useState<number[][]>([]);
  const [ignMap, setIgnMap] = useState<number[][]>([]);
  const [activeParam, setActiveParam] = useState<MapParameter>('FUEL');
  const [subView, setSubView] = useState<MapSubView>('TABLE');
  const [activePreset, setActivePreset] = useState<PresetKey>('STD');
  const [selectedCell, setSelectedCell] = useState<{ r: number; c: number }>({ r: 2, c: 2 });

  // Layer 2: Diagnostics State
  const [switches] = useState<SwitchStates>({
    stand: null,
    brakeFront: null,
    brakeRear: null,
    starter: null,
  });
  const [telemetry] = useState<SensorTelemetry>({
    rpm: null,
    tps: null,
    inj: null,
    iacv: null,
    map: null,
    ign: null,
    ect: null,
  });
  const [activeRelayTest, setActiveRelayTest] = useState<{ type: 'FP' | 'ST'; secondsLeft: number } | null>(null);

  // Layer 3: Dyno State
  const [dynoArmed, setDynoArmed] = useState(false);
  const [dynoHP, setDynoHP] = useState(0);
  const [dynoTrq, setDynoTrq] = useState(0);
  const [currentRpm, setCurrentRpm] = useState(0);
  const [dynoLog, setDynoLog] = useState<DynoPoint[]>([]);

  // Layer 4: Smartkey PIN
  const [smartkeyPin, setSmartkeyPin] = useState('---------');

  // Console Logs & In-App Modal Notice
  const [logs, setLogs] = useState<string[]>([
    'YOUNKJAYAMOTOR HYPER-TUNER X siap. Dukungan izin USB OTG Android aktif.',
  ]);
  const [notice, setNotice] = useState<AppNotice | null>(null);

  const appendLog = useCallback((msg: string) => {
    const time = new Date().toLocaleTimeString('id-ID', { hour12: false });
    setLogs((prev) => [...prev.slice(-80), `[${time}] ${msg}`]);
  }, []);

  const showNotice = useCallback(
    (title: string, message: string, tone: AppNotice['tone'] = 'info') => {
      setNotice({
        id: `${Date.now()}`,
        title,
        message,
        tone,
      });
    },
    []
  );

  const refreshOtgDiagnostics = useCallback(async () => {
    const diag = await inspectOtgDiagnostics();
    setOtgDiag(diag);
    if (diag.authorizedDevice) {
      usbDeviceRef.current = diag.authorizedDevice.rawDevice;
    } else {
      usbDeviceRef.current = null;
    }
  }, []);

  const disconnectActiveTransport = useCallback(async () => {
    setIsConnected(false);
    if (bridgeRef.current) {
      await bridgeRef.current.close();
      bridgeRef.current = null;
    }
    if (serialReaderRef.current) {
      try {
        serialReaderRef.current.releaseLock();
      } catch {
        // Ignore
      }
      serialReaderRef.current = null;
    }
    if (serialWriterRef.current) {
      try {
        serialWriterRef.current.releaseLock();
      } catch {
        // Ignore
      }
      serialWriterRef.current = null;
    }
    if (serialPortRef.current) {
      try {
        await serialPortRef.current.close();
      } catch {
        // Ignore
      }
      serialPortRef.current = null;
    }

    setConnStatusText('TERPUTUS (OFFLINE)');
    setConnTone('offline');
    appendLog('Koneksi hardware diputus.');
  }, [appendLog]);

  useEffect(() => {
    refreshOtgDiagnostics();

    if (typeof navigator !== 'undefined' && navigator.usb) {
      const onConnect = (ev: USBConnectionEvent) => {
        usbDeviceRef.current = ev.device;
        const info = formatUsbDeviceInfo(ev.device);
        refreshOtgDiagnostics();
        appendLog(`Kabel USB OTG dicolokkan: ${info.name} [VID:${info.vendorIdHex} PID:${info.productIdHex}]`);
      };

      const onDisconnect = (ev: USBConnectionEvent) => {
        if (usbDeviceRef.current === ev.device) {
          usbDeviceRef.current = null;
          disconnectActiveTransport();
        }
        refreshOtgDiagnostics();
        appendLog('Kabel USB OTG dicabut dari perangkat.');
      };

      navigator.usb.addEventListener('connect', onConnect);
      navigator.usb.addEventListener('disconnect', onDisconnect);
      return () => {
        navigator.usb?.removeEventListener('connect', onConnect);
        navigator.usb?.removeEventListener('disconnect', onDisconnect);
      };
    }
  }, [appendLog, disconnectActiveTransport, refreshOtgDiagnostics]);

  // USB OTG Permission Request
  const requestAndroidUsbOtgPermission = async (): Promise<USBDevice | null> => {
    if (!window.isSecureContext) {
      appendLog(`Gagal minta izin OTG: Bukan Secure Context (${location.protocol})`);
      showNotice(
        'Izin USB OTG Diblokir Keamanan Browser',
        `Browser Android mewajibkan halaman dibuka via HTTPS atau http://localhost (saat ini ${location.protocol}).\n\nSolusi:\n1. Buka melalui HTTPS atau localhost.\n2. Atau bungkus aplikasi menjadi APK Android menggunakan konfigurasi XML di Layer 4.`,
        'warning'
      );
      return null;
    }

    if (!navigator.usb) {
      showNotice(
        'WebUSB OTG Tidak Didukung',
        'Browser ini tidak mendukung WebUSB API untuk USB OTG Android. Gunakan Google Chrome / Edge terbaru di Android atau Desktop.',
        'error'
      );
      return null;
    }

    try {
      const options = showAllUsbDevices ? { filters: [{}] } : { filters: USB_OTG_FILTERS };
      appendLog('Meminta izin sistem Android untuk perangkat USB OTG...');
      const device = await navigator.usb.requestDevice(options);

      await device.open();
      if (device.configuration === null) {
        await device.selectConfiguration(1);
      }
      await device.close();

      usbDeviceRef.current = device;
      await refreshOtgDiagnostics();
      const info = formatUsbDeviceInfo(device);
      appendLog(`Izin USB OTG diberikan: ${info.name} [VID:${info.vendorIdHex} PID:${info.productIdHex}]`);
      showNotice(
        'Izin USB OTG Berhasil',
        `Perangkat: ${info.name}\nChipset: ${info.chipset}\nVendor ID: 0x${info.vendorIdHex} · Product ID: 0x${info.productIdHex}\n\nSekarang tekan tombol "Konek Ke Motor".`,
        'success'
      );
      return device;
    } catch (err) {
      const error = err as Error;
      if (error.name === 'NotFoundError') {
        appendLog('Permintaan izin USB OTG dibatalkan / adapter belum terpasang.');
        showNotice(
          'Perangkat USB OTG Belum Dipilih',
          'Pastikan:\n1. Fitur OTG di pengaturan HP Android sudah aktif.\n2. Kabel OTG + adapter FTDI/CH340/CP2102 sudah tersambung.',
          'warning'
        );
      } else {
        appendLog(`Error izin USB OTG: ${error.message}`);
        showNotice('Gagal Mengakses USB OTG', error.message, 'error');
      }
      return null;
    }
  };

  const revokeOrRefreshOtgDevices = async () => {
    if (isConnected) {
      await disconnectActiveTransport();
    }
    if (navigator.usb) {
      try {
        const devices = await navigator.usb.getDevices();
        for (const dev of devices) {
          if (typeof dev.forget === 'function') {
            await dev.forget();
          }
        }
      } catch {
        // Ignore forget error on older Chrome
      }
    }
    usbDeviceRef.current = null;
    await refreshOtgDiagnostics();
    appendLog('Daftar izin perangkat USB OTG telah diperbarui / di-reset.');
  };

  const openOtgSystemPanel = () => {
    setActiveLayer(4);
    setTimeout(() => {
      otgSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  // Master Connect / Disconnect
  const connectActiveTransport = async () => {
    if (isConnected) {
      await disconnectActiveTransport();
      return;
    }

    if (activeInterface !== 'SERIAL') {
      appendLog(`Jalur ${activeInterface} dipilih. Memulai bridge koneksi...`);
      showNotice(
        `Jalur ${activeInterface}`,
        `Jalur ${activeInterface} membutuhkan adapter bridge eksternal yang aktif. Untuk kabel langsung HP Android / PC, gunakan jalur OTG / FTDI.`,
        'info'
      );
      return;
    }

    if (!window.isSecureContext) {
      showNotice(
        'Halaman Tidak Aman',
        `Browser memblokir izin USB pada protokol ${location.protocol}. Gunakan HTTPS atau http://localhost.`,
        'error'
      );
      return;
    }

    const useWebUSB = isAndroidDevice() || !navigator.serial;
    appendLog(
      useWebUSB
        ? 'Menggunakan jalur Android USB OTG (WebUSB)...'
        : 'Menggunakan jalur Web Serial (Desktop / USB COM)...'
    );

    if (useWebUSB) {
      if (!navigator.usb) {
        showNotice(
          'WebUSB Tidak Tersedia',
          'Browser Anda tidak mendukung WebUSB OTG. Gunakan Google Chrome versi terbaru.',
          'error'
        );
        return;
      }

      try {
        let device = usbDeviceRef.current;
        if (!device) {
          const devices = await navigator.usb.getDevices();
          if (devices.length > 0) {
            device = devices[0];
          } else {
            device = await navigator.usb.requestDevice(
              showAllUsbDevices ? { filters: [{}] } : { filters: USB_OTG_FILTERS }
            );
          }
          usbDeviceRef.current = device;
          await refreshOtgDiagnostics();
        }

        const drv = new WebUSBSerialDriver(device);
        await drv.open(10400);

        const bridge: TransportBridge = {
          mode: 'WEBUSB',
          label: getUsbChipName(device.vendorId),
          write: (data) => drv.write(data),
          readWithTimeout: (ms = 2500) => drv.readWithTimeout(ms),
          close: () => drv.close(),
        };
        bridgeRef.current = bridge;
        appendLog(`USB OTG terbuka (${bridge.label}) @ 10400 bps`);

        // Fast-Init 25ms Break KWP2000 Honda
        await drv.setBreak(true);
        await new Promise((r) => setTimeout(r, 25));
        await drv.setBreak(false);
        await new Promise((r) => setTimeout(r, 25));

        await drv.write(KLINE_PACKETS.WAKEUP);
        appendLog('Mengirim paket K-Line Wakeup: 72 05 00 F0 99 ...');

        const rxData = await drv.readWithTimeout(3000);
        if (rxData.length > 0) {
          setIsConnected(true);
          setConnStatusText('TERHUBUNG (USB OTG 10.4K)');
          setConnTone('online');
          appendLog(`Sinyal ECU Honda KWP2000 terverifikasi! RX: ${bytesToHex(rxData)}`);
        }
      } catch (err) {
        const error = err as Error;
        setIsConnected(false);
        setConnStatusText('ECU MOTOR TIDAK MERESPON');
        setConnTone('fail');
        appendLog(`Koneksi USB OTG gagal: ${error.message}`);

        if (bridgeRef.current) {
          await bridgeRef.current.close();
          bridgeRef.current = null;
        }

        if (error.name === 'NotFoundError') {
          showNotice(
            'Kabel USB OTG Belum Dipilih',
            'Tekan tombol "Izinkan USB OTG" terlebih dahulu untuk mengotorisasi kabel adapter.',
            'warning'
          );
        } else if (error.message === 'TIMEOUT') {
          showNotice(
            'USB OTG Terhubung, ECU Tidak Merespon',
            'Pastikan:\n1. Kunci kontak motor posisi ON.\n2. Jalur K-Line (Pin DLC) tersambung benar ke kabel OTG.',
            'warning'
          );
        } else {
          showNotice('Gagal Membuka USB OTG Android', error.message, 'error');
        }
      }
      return;
    }

    // Desktop Web Serial API
    if (!navigator.serial) return;
    let port: SerialPort;
    try {
      port = await navigator.serial.requestPort();
      await port.open({ baudRate: 10400, dataBits: 8, stopBits: 1, parity: 'none' });
      serialPortRef.current = port;
      if (port.writable) {
        serialWriterRef.current = port.writable.getWriter();
      }
    } catch {
      appendLog('Pemilihan port FTDI / Serial dibatalkan.');
      showNotice('Kabel FTDI Belum Dipilih', 'Pastikan kabel FTDI / USB Serial sudah terpasang lalu pilih port COM.', 'warning');
      return;
    }

    try {
      await port.setSignals({ break: true });
      await new Promise((r) => setTimeout(r, 25));
      await port.setSignals({ break: false });
      await new Promise((r) => setTimeout(r, 25));

      if (!serialWriterRef.current || !port.readable) {
        throw new Error('Port serial tidak memiliki stream baca/tulis.');
      }

      await serialWriterRef.current.write(KLINE_PACKETS.WAKEUP);
      appendLog('Mengirim paket K-Line Wakeup: 72 05 00 F0 99 ...');

      const reader = port.readable.getReader();
      serialReaderRef.current = reader;

      const timeoutP = new Promise<never>((_, rej) => setTimeout(() => rej(new Error('TIMEOUT')), 3000));
      const res = await Promise.race([reader.read(), timeoutP]);

      if (res && res.value && res.value.length > 0) {
        bridgeRef.current = {
          mode: 'WEBSERIAL',
          label: 'Web Serial 10.4K',
          write: async (data) => {
            if (serialWriterRef.current) await serialWriterRef.current.write(data);
          },
          readWithTimeout: async (ms = 2500) => {
            if (!serialReaderRef.current) throw new Error('Reader tidak aktif');
            const tp = new Promise<never>((_, rej) => setTimeout(() => rej(new Error('TIMEOUT')), ms));
            const r = await Promise.race([serialReaderRef.current.read(), tp]);
            return r.value ?? new Uint8Array();
          },
          close: async () => {
            await disconnectActiveTransport();
          },
        };
        setIsConnected(true);
        setConnStatusText('TERHUBUNG (K-LINE 10.4K)');
        setConnTone('online');
        appendLog(`Sinyal ECU Honda KWP2000 terverifikasi! RX: ${bytesToHex(res.value)}`);
      }
    } catch (err) {
      const error = err as Error;
      setIsConnected(false);
      setConnStatusText('ECU MOTOR TIDAK MERESPON');
      setConnTone('fail');
      appendLog(`Koneksi K-Line gagal: ${error.message}`);
      await disconnectActiveTransport();
      showNotice(
        'Koneksi ECU Gagal',
        'ECU motor tidak merespon paket Fast-Init 10.400 bps. Pastikan kunci kontak ON dan pin DLC K-Line terpasang benar.',
        'error'
      );
    }
  };

  const autoDetectECU = async () => {
    if (!isConnected || !bridgeRef.current) {
      showNotice(
        'Interface Belum Terhubung',
        'Sambungkan interface USB OTG / FTDI ke motor terlebih dahulu sebelum memindai ID ECU.',
        'warning'
      );
      return;
    }

    appendLog('Memindai ID ECU via KWP2000 (72 05 71 00 18)...');
    try {
      await bridgeRef.current.write(KLINE_PACKETS.ECU_ID_REQ);
      const resp = await bridgeRef.current.readWithTimeout(2000);
      const hexResp = bytesToHex(resp);
      appendLog(`Respon ID ECU: ${hexResp}`);
      showNotice('Respon ID ECU Diterima', `Data Hex K-Line:\n${hexResp}`, 'success');
    } catch (err) {
      const error = err as Error;
      appendLog(`Auto Detect Timeout: ${error.message}`);
      showNotice('Auto Detect Timeout', 'ECU tidak membalas permintaan ID dalam batas waktu 2 detik.', 'warning');
    }
  };

  // Tuner Deck Handlers
  const unlockTableWithProfile = (
    nextRows: number,
    nextCols: number,
    banner: { name: string; details: string; icon: string },
    preset: PresetKey = 'STD'
  ) => {
    const generated = generateBaseMatrices(nextRows, nextCols);
    setRows(nextRows);
    setCols(nextCols);
    setRpmBins(generated.rpmBins);
    setTpsBins(generated.tpsBins);
    setFuelMap(generated.fuelMap);
    setIgnMap(generated.ignMap);
    setSelectedCell({ r: Math.min(2, nextRows - 1), c: Math.min(2, nextCols - 1) });
    setActivePreset(preset);
    setActiveBikeBanner(banner);
    setIsTableLoaded(true);
  };

  const handleSelectBike = (indexStr: string) => {
    setSelectedBikeIndex(indexStr);
    if (indexStr === '') {
      handleResetStandby();
      return;
    }
    const bike = database[parseInt(indexStr, 10)];
    if (!bike) return;

    unlockTableWithProfile(bike.rows, bike.cols, {
      name: bike.name,
      details: `Part: ${bike.id} · Cal: ${bike.calId} · Matriks: ${bike.rows}×${bike.cols} · Offset: ${bike.fuelOffset}`,
      icon: bike.icon,
    });
    appendLog(`Tabel dibuka untuk: ${bike.name} (${bike.id}).`);
  };

  const handleImportMapFile = (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext === 'json') {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const parsed = JSON.parse(String(e.target?.result || '{}'));
          if (Array.isArray(parsed.fuelMap) && Array.isArray(parsed.ignMap)) {
            const rCount = parsed.fuelMap.length;
            const cCount = parsed.fuelMap[0]?.length || 16;
            const generated = generateBaseMatrices(rCount, cCount);
            setRows(rCount);
            setCols(cCount);
            setRpmBins(Array.isArray(parsed.rpmBins) ? parsed.rpmBins : generated.rpmBins);
            setTpsBins(Array.isArray(parsed.tpsBins) ? parsed.tpsBins : generated.tpsBins);
            setFuelMap(parsed.fuelMap);
            setIgnMap(parsed.ignMap);
            setActiveBikeBanner({
              name: `File JSON: ${file.name}`,
              details: `Ukuran: ${(file.size / 1024).toFixed(1)} KB · Matriks ${rCount}×${cCount}`,
              icon: '📂',
            });
            setIsTableLoaded(true);
            appendLog(`File JSON map dimuat: ${file.name}`);
            return;
          }
        } catch {
          // Fall through to standard load
        }
        unlockTableWithProfile(16, 16, {
          name: `File: ${file.name}`,
          details: `Ukuran: ${(file.size / 1024).toFixed(1)} KB · Dimuat Manual`,
          icon: '📂',
        });
      };
      reader.readAsText(file);
      return;
    }

    unlockTableWithProfile(16, 16, {
      name: `File: ${file.name}`,
      details: `Ukuran: ${(file.size / 1024).toFixed(1)} KB · Dimuat Manual`,
      icon: '📂',
    });
    appendLog(`File map dimuat: ${file.name}`);
  };

  const handleResetStandby = () => {
    setIsTableLoaded(false);
    setSelectedBikeIndex('');
    setActiveBikeBanner(null);
    appendLog('Tabel pemetaan ditutup kembali ke status Standby.');
  };

  const handleUpdateCell = (r: number, c: number, val: number) => {
    const rounded = parseFloat(val.toFixed(1));
    if (activeParam === 'IGN') {
      setIgnMap((prev) =>
        prev.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? rounded : cell)) : row))
      );
    } else {
      setFuelMap((prev) =>
        prev.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? rounded : cell)) : row))
      );
    }
  };

  const handleAdjustSelectedCell = (delta: number) => {
    const matrix = activeParam === 'IGN' ? ignMap : fuelMap;
    const currentVal = matrix[selectedCell.r]?.[selectedCell.c];
    if (typeof currentVal === 'number') {
      handleUpdateCell(selectedCell.r, selectedCell.c, currentVal + delta);
    }
  };

  const handleApplyPreset = (preset: PresetKey) => {
    setActivePreset(preset);
    const fuelMultipliers: Record<PresetKey, number> = {
      STD: 1.0,
      TOURING: 1.03,
      STOP_N_GO: 1.02,
      RACE: 1.08,
      DRAG: 1.12,
      TIMING_KUDA: 1.05,
      IDLE_ROTARY: 1.04,
      BLACK_FAIR: 1.1,
    };
    const ignOffsets: Record<PresetKey, number> = {
      STD: 0,
      TOURING: 1.2,
      STOP_N_GO: 0.8,
      RACE: 2.8,
      DRAG: 3.5,
      TIMING_KUDA: -3.2,
      IDLE_ROTARY: -1.8,
      BLACK_FAIR: 4.0,
    };

    const base = generateBaseMatrices(rows, cols);
    const fMult = fuelMultipliers[preset];
    const iOff = ignOffsets[preset];

    setFuelMap(
      base.fuelMap.map((row, r) =>
        row.map((v, c) => {
          if (preset === 'TIMING_KUDA' && r <= 2 && c <= 2) return parseFloat((v * 1.12).toFixed(1));
          return parseFloat((v * fMult).toFixed(1));
        })
      )
    );
    setIgnMap(
      base.ignMap.map((row, r) =>
        row.map((v, c) => {
          if (preset === 'TIMING_KUDA' && r <= 2 && c <= 2) return parseFloat(Math.max(4, v - 4.5).toFixed(1));
          return parseFloat((v + iOff).toFixed(1));
        })
      )
    );
    appendLog(`Preset pemetaan "${preset}" diterapkan ke tabel bensin & pengapian.`);
  };

  const handleSmoothInterpolate = () => {
    const source = activeParam === 'IGN' ? ignMap : fuelMap;
    if (source.length === 0) return;

    const smoothed = source.map((row, r) =>
      row.map((val, c) => {
        if (r === 0 || c === 0 || r === rows - 1 || c === cols - 1) return val;
        const avg =
          (source[r - 1][c] + source[r + 1][c] + source[r][c - 1] + source[r][c + 1] + val * 2) / 6;
        return parseFloat(avg.toFixed(1));
      })
    );

    if (activeParam === 'IGN') setIgnMap(smoothed);
    else setFuelMap(smoothed);

    appendLog(`Interpolasi rata diterapkan pada peta ${activeParam === 'IGN' ? 'Pengapian' : 'Bahan Bakar'}.`);
    showNotice('Interpolasi Selesai', 'Kurva peta berhasil dihaluskan menggunakan perataan 4-tetangga.', 'success');
  };

  // Diagnostics Relay Test (3 seconds Mode 0x30)
  const handleTestRelay = async (type: 'FP' | 'ST', seconds: number) => {
    const label = type === 'FP' ? 'Pompa Bensin (Fuel Pump)' : 'Relay Starter ACG';
    appendLog(`Menguji ${label} Mode 0x30 selama ${seconds} detik...`);

    if (isConnected && bridgeRef.current) {
      try {
        const pkt = type === 'FP' ? KLINE_PACKETS.RELAY_FUEL_PUMP : KLINE_PACKETS.RELAY_STARTER;
        await bridgeRef.current.write(pkt);
        appendLog(`Paket Mode 0x30 terkirim: ${bytesToHex(pkt)}`);
      } catch (err) {
        appendLog(`Gagal kirim perintah relay: ${(err as Error).message}`);
      }
    }

    setActiveRelayTest({ type, secondsLeft: seconds });
    let remain = seconds;
    const timer = window.setInterval(() => {
      remain -= 1;
      if (remain <= 0) {
        window.clearInterval(timer);
        setActiveRelayTest(null);
        appendLog(`Uji ${label} selesai (${seconds} detik).`);
        showNotice('Uji Relay Selesai', `Pengujian ${label} selama ${seconds} detik telah selesai.`, 'success');
      } else {
        setActiveRelayTest({ type, secondsLeft: remain });
      }
    }, 1000);
  };

  // Dyno Recording & CSV Export
  const handleToggleDyno = () => {
    if (!dynoArmed) {
      setDynoLog([]);
      setDynoHP(0);
      setDynoTrq(0);
      setCurrentRpm(1500);
      setDynoArmed(true);
      appendLog('Perekaman Virtual Dyno dimulai. Menunggu tarikan RPM dari sensor ECU...');
    } else {
      setDynoArmed(false);
      appendLog(`Perekaman Dyno dihentikan. Peak: ${dynoHP.toFixed(2)} HP / ${dynoTrq.toFixed(2)} Nm.`);
      showNotice(
        'Tarikan Dyno Selesai',
        `Peak Tercatat: ${dynoHP.toFixed(2)} HP · ${dynoTrq.toFixed(2)} Nm (${dynoLog.length} sampel).`,
        'success'
      );
    }
  };

  const handleExportDynoCsv = () => {
    const header = 'RPM,Power_HP,Torque_Nm\n';
    const body =
      dynoLog.length > 0
        ? dynoLog.map((p) => `${p.r},${p.hp.toFixed(2)},${p.trq.toFixed(2)}`).join('\n')
        : `${currentRpm},${dynoHP.toFixed(2)},${dynoTrq.toFixed(2)}`;
    const blob = new Blob([header + body], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `younkjayamotor_dyno_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    appendLog('Log Dyno CSV berhasil diexport.');
  };

  // Layer 4: Save Custom Motorcycle & Smartkey Read
  const handleSaveCustomBike = (bike: MotorcycleProfile) => {
    const updated = saveCustomMotorcycleToStorage(bike);
    setDatabase(updated);
    appendLog(`Motor baru disimpan permanen: ${bike.id} - ${bike.name} (${bike.vendor})`);
  };

  const handleReadSmartkeyPin = async () => {
    if (!isConnected || !bridgeRef.current) {
      showNotice(
        'Kabel Belum Terkoneksi',
        'Sambungkan kabel USB OTG / FTDI ke motor atau SCU terlebih dahulu untuk membaca PIN asli.',
        'warning'
      );
      return;
    }

    appendLog('Mengirim permintaan ekstraksi PIN SCU/ECM via K-Line...');
    try {
      await bridgeRef.current.write(KLINE_PACKETS.SMARTKEY_PIN_REQ);
      const resp = await bridgeRef.current.readWithTimeout(2500);
      const decoded = bytesToHex(resp).replace(/\s+/g, '').slice(0, 9) || '000000000';
      setSmartkeyPin(decoded);
      appendLog(`PIN SCU diterima: ${decoded}`);
      showNotice('Ekstraksi PIN SCU Berhasil', `PIN / ID Terbaca: ${decoded}`, 'success');
    } catch (err) {
      appendLog(`Gagal baca PIN SCU: ${(err as Error).message}`);
      showNotice('Timeout Baca PIN SCU', 'Unit SCU/ECM tidak memberikan respon PIN dalam batas waktu.', 'warning');
    }
  };

  const navItems: Array<{ id: LayerId; label: string; shortLabel: string; icon: React.ReactNode }> = [
    { id: 1, label: 'Tuner Deck', shortLabel: 'Mapping', icon: <Sliders className="h-4 w-4" /> },
    { id: 2, label: 'Diagnostik', shortLabel: 'Diagnostik', icon: <Activity className="h-4 w-4" /> },
    { id: 3, label: 'Real Dyno', shortLabel: 'Dyno', icon: <TrendingUp className="h-4 w-4" /> },
    { id: 4, label: 'XDF, OTG & DB', shortLabel: 'XDF & OTG', icon: <Wrench className="h-4 w-4" /> },
  ];

  const transportButtons: Array<{ mode: TransportMode; label: string; icon: React.ReactNode }> = [
    { mode: 'SERIAL', label: 'OTG / FTDI', icon: <Usb className="h-3.5 w-3.5" /> },
    { mode: 'BLUETOOTH', label: 'Bluetooth', icon: <Bluetooth className="h-3.5 w-3.5" /> },
    { mode: 'WIFI', label: 'Wi-Fi AP', icon: <Wifi className="h-3.5 w-3.5" /> },
    { mode: 'CAN', label: 'CAN Bus', icon: <Cpu className="h-3.5 w-3.5" /> },
  ];

  return (
    <div className="min-h-screen bg-[#090B10] pb-20 text-slate-100 md:pb-8">
      {/* Top Bar Contract: Zone 1 Brand | Zone 2 4 Nav Links | Zone 3 1 Primary Action */}
      <header className="sticky top-0 z-40 border-b border-slate-800 bg-[#0B0E15]/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2.5 sm:px-6">
          <button
            type="button"
            onClick={() => setActiveLayer(1)}
            className="font-[var(--font-display)] text-base font-bold tracking-wider text-white whitespace-nowrap shrink-0 sm:text-lg"
          >
            YOUNKJAYA<span className="text-[#FF1E42]">MOTOR</span> HYPER-TUNER X
          </button>

          <nav className="hidden items-center gap-6 md:flex">
            {navItems.map((item) => {
              const isAct = activeLayer === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveLayer(item.id)}
                  className={`border-b-2 py-1 text-xs font-semibold tracking-wide transition-colors whitespace-nowrap shrink-0 ${
                    isAct
                      ? 'border-[#FF1E42] text-white'
                      : 'border-transparent text-slate-400 hover:text-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <button
            type="button"
            onClick={connectActiveTransport}
            className={`min-h-[40px] rounded-md px-3.5 py-2 text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
              isConnected
                ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
            }`}
          >
            {isConnected ? 'Putus Koneksi ECU' : 'Konek Ke Motor'}
          </button>
        </div>
      </header>

      {/* Workspace Hardware & USB OTG Toolbar */}
      <div className="border-b border-slate-800 bg-[#0D1119]">
        <div className="mx-auto max-w-7xl space-y-2.5 px-4 py-3 sm:px-6">
          {/* Status + Auto Detect + OTG Quick Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span
                className={`font-semibold ${
                  connTone === 'online'
                    ? 'text-emerald-400'
                    : connTone === 'fail'
                    ? 'text-rose-400'
                    : 'text-slate-400'
                }`}
              >
                {connTone === 'online' ? '● ' : connTone === 'fail' ? '✖ ' : '■ '}
                {connStatusText}
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-300">
                USB OTG:{' '}
                {otgDiag.authorizedDevice ? (
                  <strong className="text-emerald-400">
                    {otgDiag.authorizedDevice.name} [VID:{otgDiag.authorizedDevice.vendorIdHex}]
                  </strong>
                ) : (
                  <span className="text-amber-300">Menunggu izin perangkat</span>
                )}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={autoDetectECU}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-md bg-amber-400 px-3 py-1.5 text-xs font-bold text-slate-950 transition-colors hover:bg-amber-300 whitespace-nowrap"
              >
                <Search className="h-3.5 w-3.5" />
                Auto Detect ECU
              </button>
              <button
                type="button"
                onClick={requestAndroidUsbOtgPermission}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-md bg-emerald-500 px-3 py-1.5 text-xs font-bold text-slate-950 transition-colors hover:bg-emerald-400 whitespace-nowrap"
              >
                <Usb className="h-3.5 w-3.5" />
                Izinkan USB OTG
              </button>
              <button
                type="button"
                onClick={openOtgSystemPanel}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-md border border-cyan-500/50 bg-[#090B10] px-3 py-1.5 text-xs font-semibold text-cyan-300 transition-colors hover:bg-slate-900 whitespace-nowrap"
              >
                Diag OTG
              </button>
            </div>
          </div>

          {/* Hardware Transport Selector */}
          <div className="grid grid-cols-4 gap-1.5">
            {transportButtons.map((tb) => {
              const isAct = activeInterface === tb.mode;
              return (
                <button
                  key={tb.mode}
                  type="button"
                  onClick={() => {
                    setActiveInterface(tb.mode);
                    appendLog(`Jalur interface hardware dipilih: ${tb.mode}`);
                  }}
                  className={`inline-flex min-h-[38px] items-center justify-center gap-1.5 rounded-md border px-2 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    isAct
                      ? 'border-cyan-400 bg-cyan-950/30 text-cyan-300'
                      : 'border-slate-800 bg-[#090B10] text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {tb.icon}
                  <span className="truncate">{tb.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Workspace */}
      <main className="mx-auto max-w-7xl space-y-4 px-4 py-4 sm:px-6">
        {activeLayer === 1 && (
          <TunerDeckLayer
            database={database}
            selectedBikeIndex={selectedBikeIndex}
            activeBikeBanner={activeBikeBanner}
            isTableLoaded={isTableLoaded}
            rows={rows}
            cols={cols}
            rpmBins={rpmBins}
            tpsBins={tpsBins}
            fuelMap={fuelMap}
            ignMap={ignMap}
            activeParam={activeParam}
            subView={subView}
            activePreset={activePreset}
            selectedCell={selectedCell}
            onSelectBike={handleSelectBike}
            onImportMapFile={handleImportMapFile}
            onResetStandby={handleResetStandby}
            onChangeParam={setActiveParam}
            onChangeSubView={setSubView}
            onSelectCell={(r, c) => setSelectedCell({ r, c })}
            onUpdateCell={handleUpdateCell}
            onAdjustSelectedCell={handleAdjustSelectedCell}
            onApplyPreset={handleApplyPreset}
            onSmoothInterpolate={handleSmoothInterpolate}
          />
        )}

        {activeLayer === 2 && (
          <DiagnosticsLayer
            isConnected={isConnected}
            switches={switches}
            telemetry={telemetry}
            activeRelayTest={activeRelayTest}
            onTestRelay={handleTestRelay}
          />
        )}

        {activeLayer === 3 && (
          <RealDynoLayer
            dynoArmed={dynoArmed}
            dynoHP={dynoHP}
            dynoTrq={dynoTrq}
            currentRpm={currentRpm}
            dynoLog={dynoLog}
            onToggleDyno={handleToggleDyno}
            onExportCsv={handleExportDynoCsv}
          />
        )}

        {activeLayer === 4 && (
          <XdfOtgDatabaseLayer
            otgDiag={otgDiag}
            showAllUsbDevices={showAllUsbDevices}
            onToggleShowAllUsb={setShowAllUsbDevices}
            onRequestOtgPermission={requestAndroidUsbOtgPermission}
            onRevokeOrRefreshOtg={revokeOrRefreshOtgDevices}
            database={database}
            onSaveCustomBike={handleSaveCustomBike}
            onNotify={showNotice}
            onLog={appendLog}
            isConnected={isConnected}
            smartkeyPin={smartkeyPin}
            onReadSmartkeyPin={handleReadSmartkeyPin}
            otgSectionRef={otgSectionRef}
          />
        )}

        {/* System Hardware Activity Log */}
        <section className="rounded-lg border border-slate-800 bg-[#11151E] p-4">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-[var(--font-display)] text-xs font-bold tracking-wider text-slate-300 uppercase">
              System Hardware Activity Log
            </h3>
            <button
              type="button"
              onClick={() => setLogs(['Log aktivitas dibersihkan.'])}
              className="text-xs font-medium text-slate-400 hover:text-slate-200"
            >
              Bersihkan Log
            </button>
          </div>
          <div className="h-28 overflow-y-auto rounded-md border border-slate-800 bg-[#07090E] p-2.5 font-mono text-[11px] leading-relaxed text-emerald-400">
            {logs.map((line, i) => (
              <div key={i}>&gt; {line}</div>
            ))}
          </div>
        </section>
      </main>

      {/* Mobile Bottom Navigation (Thumb Zone) */}
      <nav className="fixed right-0 bottom-0 left-0 z-40 grid h-14 grid-cols-4 border-t border-slate-800 bg-[#0B0E15]/95 backdrop-blur-md md:hidden">
        {navItems.map((item) => {
          const isAct = activeLayer === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveLayer(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 border-t-2 text-[10px] font-bold transition-colors ${
                isAct
                  ? 'border-[#FF1E42] bg-[#1A080D] text-white'
                  : 'border-transparent text-slate-400'
              }`}
            >
              {item.icon}
              <span>{item.shortLabel}</span>
            </button>
          );
        })}
      </nav>

      {/* In-App Modal Notice (Replaces window.alert) */}
      {notice && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-lg border border-slate-700 bg-[#11151E] p-5 shadow-2xl">
            <div className="mb-3 flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                {notice.tone === 'success' && <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />}
                {notice.tone === 'warning' && <AlertTriangle className="h-5 w-5 shrink-0 text-amber-400" />}
                {notice.tone === 'error' && <AlertTriangle className="h-5 w-5 shrink-0 text-rose-400" />}
                {notice.tone === 'info' && <Info className="h-5 w-5 shrink-0 text-cyan-400" />}
                <h3 className="font-[var(--font-display)] text-base font-bold text-white">
                  {notice.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setNotice(null)}
                className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
                aria-label="Tutup dialog"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="whitespace-pre-line text-sm leading-relaxed text-slate-300">
              {notice.message}
            </p>
            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={() => setNotice(null)}
                className="min-h-[40px] rounded-md bg-cyan-500 px-5 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-400"
              >
                Mengerti
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
