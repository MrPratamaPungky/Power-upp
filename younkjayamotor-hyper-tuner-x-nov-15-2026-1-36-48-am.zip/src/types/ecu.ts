export type TransportMode = 'SERIAL' | 'BLUETOOTH' | 'WIFI' | 'CAN';
export type MapParameter = 'FUEL' | 'IGN';
export type MapSubView = 'TABLE' | 'CURVE2D' | 'SURFACE3D';
export type LayerId = 1 | 2 | 3 | 4;
export type PresetKey =
  | 'STD'
  | 'TOURING'
  | 'STOP_N_GO'
  | 'RACE'
  | 'DRAG'
  | 'TIMING_KUDA'
  | 'IDLE_ROTARY'
  | 'BLACK_FAIR';

export interface ArchConfig {
  size: string;
  vendor: string;
  fuelOffset: string;
  ignOffset: string;
  limiterOffset: string;
  rows: number;
  cols: number;
  o2Offset: string;
  sideOffset: string;
  checksumType: string;
  icon: string;
}

export interface MotorcycleProfile {
  id: string;
  calId: string;
  name: string;
  issType: string;
  size: string;
  vendor: string;
  fuelOffset: string;
  ignOffset: string;
  limiterOffset: string;
  rows: number;
  cols: number;
  icon: string;
  isCustom?: boolean;
}

export interface DynoPoint {
  r: number;
  hp: number;
  trq: number;
}

export interface SwitchStates {
  stand: boolean | null;
  brakeFront: boolean | null;
  brakeRear: boolean | null;
  starter: boolean | null;
}

export interface SensorTelemetry {
  rpm: number | null;
  tps: number | null;
  inj: number | null;
  iacv: number | null;
  map: number | null;
  ign: number | null;
  ect: number | null;
}

export interface OtgDeviceInfo {
  name: string;
  chipset: string;
  vendorIdHex: string;
  productIdHex: string;
  rawDevice: USBDevice;
}

export interface OtgDiagnostics {
  isAndroid: boolean;
  isSecureContext: boolean;
  protocol: string;
  hasWebUsb: boolean;
  hasWebSerial: boolean;
  authorizedDevice: OtgDeviceInfo | null;
}

export interface AppNotice {
  id: string;
  title: string;
  message: string;
  tone: 'info' | 'success' | 'warning' | 'error';
}
